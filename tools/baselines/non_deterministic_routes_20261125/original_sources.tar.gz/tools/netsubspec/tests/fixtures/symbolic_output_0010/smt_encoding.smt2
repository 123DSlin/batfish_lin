(declare-fun Config_r4_RouteFilterList_pl__Line1__10_0_0_0__ip () (_ BitVec 32))
(declare-fun Config_r4_RouteFilterList_pl__Line1__10_0_0_0__mask
             ()
             (_ BitVec 32))
(declare-fun Config_r4_RouteFilterList_pl__Line1__10_0_0_0__length () Int)
(declare-fun Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start
             ()
             Int)
(declare-fun Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end
             ()
             Int)
(declare-fun Config_r4_RouteFilterList_pl__Line1__10_0_0_0__enable () Bool)
(declare-fun Config_r4_RouteFilterList_pl__Line1__10_0_0_0__action () Bool)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line1__match_prefixlist_enable
             ()
             Bool)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line2__set_localpreference_100
             ()
             Int)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line2__set_localpreference_100enable
             ()
             Bool)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line1__match_prefixlist_enable
             ()
             Bool)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line2__set_localpreference_200
             ()
             Int)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line2__set_localpreference_200enable
             ()
             Bool)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line1__match_prefixlist_enable
             ()
             Bool)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line2__set_localpreference_50
             ()
             Int)
(declare-fun Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line2__set_localpreference_50enable
             ()
             Bool)
(declare-fun Config_r1_RouteFilterList_pl__Line1__10_0_0_0__ip () (_ BitVec 32))
(declare-fun Config_r1_RouteFilterList_pl__Line1__10_0_0_0__mask
             ()
             (_ BitVec 32))
(declare-fun Config_r1_RouteFilterList_pl__Line1__10_0_0_0__length () Int)
(declare-fun Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start
             ()
             Int)
(declare-fun Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end
             ()
             Int)
(declare-fun Config_r1_RouteFilterList_pl__Line1__10_0_0_0__enable () Bool)
(declare-fun Config_r1_RouteFilterList_pl__Line1__10_0_0_0__action () Bool)
(declare-fun Config_r1_RoutingPolicy_REDISTRIBUTE_CONNECTED__Seq10__Line1__match_prefixlist_enable
             ()
             Bool)
(declare-fun |0_FAILED-EDGE_r2_r4| () Int)
(declare-fun |0_FAILED-EDGE_r1_Loopback0| () Int)
(declare-fun |0_FAILED-EDGE_r1_r3| () Int)
(declare-fun |0_FAILED-EDGE_r1_r4| () Int)
(declare-fun |0_FAILED-EDGE_r1_r2| () Int)
(declare-fun |0_FAILED-EDGE_r3_r4| () Int)
(declare-fun |0_FAILED-NODE_r4| () Int)
(declare-fun |0_FAILED-NODE_r3| () Int)
(declare-fun |0_FAILED-NODE_r1| () Int)
(declare-fun |0_FAILED-NODE_r2| () Int)
(declare-fun |0_dst-port| () Int)
(declare-fun |0_src-port| () Int)
(declare-fun |0_icmp-type| () Int)
(declare-fun |0_ip-protocol| () Int)
(declare-fun |0_icmp-code| () Int)
(declare-fun |0_r2_OVERALL_BEST_None_routerID| () Int)
(declare-fun |0_r2_OVERALL_BEST_None_med| () Int)
(declare-fun |0_r2_OVERALL_BEST_None_localPref| () Int)
(declare-fun |0_r2_OVERALL_BEST_None_metric| () Int)
(declare-fun |0_r2_OVERALL_BEST_None_prefixLength| () Int)
(declare-fun |0_r3_OVERALL_BEST_None_routerID| () Int)
(declare-fun |0_r3_OVERALL_BEST_None_med| () Int)
(declare-fun |0_r3_OVERALL_BEST_None_localPref| () Int)
(declare-fun |0_r3_OVERALL_BEST_None_metric| () Int)
(declare-fun |0_r3_OVERALL_BEST_None_prefixLength| () Int)
(declare-fun |0_r4_OVERALL_BEST_None_routerID| () Int)
(declare-fun |0_r4_OVERALL_BEST_None_med| () Int)
(declare-fun |0_r4_OVERALL_BEST_None_localPref| () Int)
(declare-fun |0_r4_OVERALL_BEST_None_metric| () Int)
(declare-fun |0_r4_OVERALL_BEST_None_prefixLength| () Int)
(declare-fun |0_r1_OVERALL_BEST_None_routerID| () Int)
(declare-fun |0_r1_OVERALL_BEST_None_adminDist| () Int)
(declare-fun |0_r1_OVERALL_BEST_None_med| () Int)
(declare-fun |0_r1_OVERALL_BEST_None_localPref| () Int)
(declare-fun |0_r1_OVERALL_BEST_None_metric| () Int)
(declare-fun |0_r1_OVERALL_BEST_None_prefixLength| () Int)
(declare-fun |0_r1_BGP_BEST_None_routerID| () Int)
(declare-fun |0_r1_BGP_BEST_None_med| () Int)
(declare-fun |0_r1_BGP_BEST_None_localPref| () Int)
(declare-fun |0_r1_BGP_BEST_None_metric| () Int)
(declare-fun |0_r1_BGP_BEST_None_prefixLength| () Int)
(declare-fun |0_r1_CONNECTED_BEST_None_prefixLength| () Int)
(declare-fun |0_r2_BGP_EXPORT_Ethernet21_med| () Int)
(declare-fun |0_r2_BGP_EXPORT_Ethernet21_localPref| () Int)
(declare-fun |0_r2_BGP_EXPORT_Ethernet21_metric| () Int)
(declare-fun |0_r2_BGP_EXPORT_Ethernet21_prefixLength| () Int)
(declare-fun |0_r2_BGP_IMPORT_Ethernet21_med| () Int)
(declare-fun |0_r2_BGP_IMPORT_Ethernet21_localPref| () Int)
(declare-fun |0_r2_BGP_IMPORT_Ethernet21_metric| () Int)
(declare-fun |0_r2_BGP_IMPORT_Ethernet21_prefixLength| () Int)
(declare-fun |0_r2_BGP_EXPORT_Ethernet24_med| () Int)
(declare-fun |0_r2_BGP_EXPORT_Ethernet24_localPref| () Int)
(declare-fun |0_r2_BGP_EXPORT_Ethernet24_metric| () Int)
(declare-fun |0_r2_BGP_EXPORT_Ethernet24_prefixLength| () Int)
(declare-fun |0_r3_BGP_EXPORT_Ethernet34_med| () Int)
(declare-fun |0_r3_BGP_EXPORT_Ethernet34_localPref| () Int)
(declare-fun |0_r3_BGP_EXPORT_Ethernet34_metric| () Int)
(declare-fun |0_r3_BGP_EXPORT_Ethernet34_prefixLength| () Int)
(declare-fun |0_r3_BGP_EXPORT_Ethernet31_med| () Int)
(declare-fun |0_r3_BGP_EXPORT_Ethernet31_localPref| () Int)
(declare-fun |0_r3_BGP_EXPORT_Ethernet31_metric| () Int)
(declare-fun |0_r3_BGP_EXPORT_Ethernet31_prefixLength| () Int)
(declare-fun |0_r3_BGP_IMPORT_Ethernet31_med| () Int)
(declare-fun |0_r3_BGP_IMPORT_Ethernet31_localPref| () Int)
(declare-fun |0_r3_BGP_IMPORT_Ethernet31_metric| () Int)
(declare-fun |0_r3_BGP_IMPORT_Ethernet31_prefixLength| () Int)
(declare-fun |0_r4_BGP_SINGLE-EXPORT__med| () Int)
(declare-fun |0_r4_BGP_SINGLE-EXPORT__localPref| () Int)
(declare-fun |0_r4_BGP_SINGLE-EXPORT__metric| () Int)
(declare-fun |0_r4_BGP_SINGLE-EXPORT__prefixLength| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet41_med| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet41_localPref| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet41_metric| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet41_prefixLength| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet43_med| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet43_localPref| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet43_metric| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet43_prefixLength| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet42_med| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet42_localPref| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet42_metric| () Int)
(declare-fun |0_r4_BGP_IMPORT_Ethernet42_prefixLength| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet12_med| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet12_localPref| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet12_metric| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet12_prefixLength| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet13_med| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet13_localPref| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet13_metric| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet13_prefixLength| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet14_med| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet14_localPref| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet14_metric| () Int)
(declare-fun |0_r1_BGP_EXPORT_Ethernet14_prefixLength| () Int)
(declare-fun |0_r1_CONNECTED_IMPORT_Loopback0_prefixLength| () Int)
(declare-fun |0_r2_BGP_IMPORT_Ethernet21_permitted| () Bool)
(declare-fun |0_r1_BGP_EXPORT_Ethernet12_permitted| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r1_Ethernet12| () Bool)
(declare-fun |0_r2_BGP_EXPORT_Ethernet21_permitted| () Bool)
(declare-fun |0_r2_OVERALL_BEST_None_permitted| () Bool)
(declare-fun |0_r2_BGP_EXPORT_Ethernet24_permitted| () Bool)
(declare-fun |0_r3_BGP_EXPORT_Ethernet34_permitted| () Bool)
(declare-fun |0_r3_OVERALL_BEST_None_permitted| () Bool)
(declare-fun |0_r3_BGP_IMPORT_Ethernet31_permitted| () Bool)
(declare-fun |0_r1_BGP_EXPORT_Ethernet13_permitted| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r1_Ethernet13| () Bool)
(declare-fun |0_r3_BGP_EXPORT_Ethernet31_permitted| () Bool)
(declare-fun |0_r4_BGP_IMPORT_Ethernet41_permitted| () Bool)
(declare-fun |0_dst-ip| () (_ BitVec 32))
(declare-fun |0_r1_BGP_EXPORT_Ethernet14_permitted| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r1_Ethernet14| () Bool)
(declare-fun |0_r4_BGP_SINGLE-EXPORT__permitted| () Bool)
(declare-fun |0_r4_OVERALL_BEST_None_permitted| () Bool)
(declare-fun |0_r4_BGP_IMPORT_Ethernet43_permitted| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r3_Ethernet34| () Bool)
(declare-fun |0_r4_BGP_IMPORT_Ethernet42_permitted| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r2_Ethernet24| () Bool)
(declare-fun |0_r1_OVERALL_BEST_None_history| () (_ BitVec 1))
(declare-fun |0_r1_OVERALL_BEST_None_permitted| () Bool)
(declare-fun |0_r1_CONNECTED_BEST_None_permitted| () Bool)
(declare-fun |0_r1_BGP_BEST_None_permitted| () Bool)
(declare-fun |0_r2_BGP_IMPORT_Ethernet21_choice| () Bool)
(declare-fun |0_r2_BGP_IMPORT_Ethernet24_choice| () Bool)
(declare-fun |0_r3_BGP_IMPORT_Ethernet31_choice| () Bool)
(declare-fun |0_r3_BGP_IMPORT_Ethernet34_choice| () Bool)
(declare-fun |0_r4_BGP_IMPORT_Ethernet41_choice| () Bool)
(declare-fun |0_r4_BGP_IMPORT_Ethernet43_choice| () Bool)
(declare-fun |0_r4_BGP_IMPORT_Ethernet42_choice| () Bool)
(declare-fun |0_r1_BGP_IMPORT_Ethernet13_choice| () Bool)
(declare-fun |0_r1_BGP_IMPORT_Ethernet14_choice| () Bool)
(declare-fun |0_r1_BGP_IMPORT_Ethernet12_choice| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r2_Ethernet21| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r3_Ethernet31| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r4_Ethernet41| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r4_Ethernet43| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r4_Ethernet42| () Bool)
(declare-fun |0_CONTROL-FORWARDING_r1_Loopback0| () Bool)
(declare-fun |0_DATA-FORWARDING_r2_Ethernet21| () Bool)
(declare-fun |0_DATA-FORWARDING_r2_Ethernet24| () Bool)
(declare-fun |0_DATA-FORWARDING_r3_Ethernet34| () Bool)
(declare-fun |0_DATA-FORWARDING_r3_Ethernet31| () Bool)
(declare-fun |0_DATA-FORWARDING_r4_Ethernet41| () Bool)
(declare-fun |0_DATA-FORWARDING_r4_Ethernet43| () Bool)
(declare-fun |0_DATA-FORWARDING_r4_Ethernet42| () Bool)
(declare-fun |0_DATA-FORWARDING_r1_Loopback0| () Bool)
(declare-fun |0_DATA-FORWARDING_r1_Ethernet12| () Bool)
(declare-fun |0_DATA-FORWARDING_r1_Ethernet13| () Bool)
(declare-fun |0_DATA-FORWARDING_r1_Ethernet14| () Bool)
(declare-fun |0_r1_CONNECTED_IMPORT_Loopback0_permitted| () Bool)
(declare-fun |0__reachable-id_r2| () Int)
(declare-fun |0__reachable_r2| () Bool)
(declare-fun |0__reachable-id_r3| () Int)
(declare-fun |0__reachable_r3| () Bool)
(declare-fun |0__reachable-id_r4| () Int)
(declare-fun |0__reachable_r4| () Bool)
(declare-fun |0__reachable-id_r1| () Int)
(declare-fun |0__reachable_r1| () Bool)
(assert (= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__ip #x0a000000))
(assert (= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__mask #xffffff00))
(assert (= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__length 24))
(assert (= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start 24))
(assert (= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end 24))
(assert (= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__enable true))
(assert (= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__action true))
(assert (>= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start
    Config_r4_RouteFilterList_pl__Line1__10_0_0_0__length))
(assert (>= Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end
    Config_r4_RouteFilterList_pl__Line1__10_0_0_0__length))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line1__match_prefixlist_enable
   true))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line2__set_localpreference_100
   100))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line2__set_localpreference_100enable
   true))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line1__match_prefixlist_enable
   true))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line2__set_localpreference_200
   200))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line2__set_localpreference_200enable
   true))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line1__match_prefixlist_enable
   true))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line2__set_localpreference_50
   50))
(assert (= Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line2__set_localpreference_50enable
   true))
(assert (= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__ip #x0a000000))
(assert (= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__mask #xffffff00))
(assert (= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__length 24))
(assert (= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start 24))
(assert (= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end 24))
(assert (= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__enable true))
(assert (= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__action true))
(assert (>= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start
    Config_r1_RouteFilterList_pl__Line1__10_0_0_0__length))
(assert (>= Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end
    Config_r1_RouteFilterList_pl__Line1__10_0_0_0__length))
(assert (= Config_r1_RoutingPolicy_REDISTRIBUTE_CONNECTED__Seq10__Line1__match_prefixlist_enable
   true))
(assert (>= |0_FAILED-EDGE_r2_r4| 0))
(assert (<= |0_FAILED-EDGE_r2_r4| 1))
(assert (>= |0_FAILED-EDGE_r1_Loopback0| 0))
(assert (<= |0_FAILED-EDGE_r1_Loopback0| 1))
(assert (>= |0_FAILED-EDGE_r1_r3| 0))
(assert (<= |0_FAILED-EDGE_r1_r3| 1))
(assert (>= |0_FAILED-EDGE_r1_r4| 0))
(assert (<= |0_FAILED-EDGE_r1_r4| 1))
(assert (>= |0_FAILED-EDGE_r1_r2| 0))
(assert (<= |0_FAILED-EDGE_r1_r2| 1))
(assert (>= |0_FAILED-EDGE_r3_r4| 0))
(assert (<= |0_FAILED-EDGE_r3_r4| 1))
(assert (= |0_FAILED-EDGE_r2_r4| 0))
(assert (= |0_FAILED-EDGE_r1_Loopback0| 0))
(assert (= |0_FAILED-EDGE_r1_r3| 0))
(assert (= |0_FAILED-EDGE_r1_r4| 0))
(assert (= |0_FAILED-EDGE_r1_r2| 0))
(assert (= |0_FAILED-EDGE_r3_r4| 0))
(assert (>= |0_FAILED-NODE_r4| 0))
(assert (<= |0_FAILED-NODE_r4| 1))
(assert (>= |0_FAILED-NODE_r3| 0))
(assert (<= |0_FAILED-NODE_r3| 1))
(assert (>= |0_FAILED-NODE_r1| 0))
(assert (<= |0_FAILED-NODE_r1| 1))
(assert (>= |0_FAILED-NODE_r2| 0))
(assert (<= |0_FAILED-NODE_r2| 1))
(assert (= |0_FAILED-NODE_r4| 0))
(assert (= |0_FAILED-NODE_r3| 0))
(assert (= |0_FAILED-NODE_r1| 0))
(assert (= |0_FAILED-NODE_r2| 0))
(assert (>= |0_dst-port| 0))
(assert (>= |0_src-port| 0))
(assert (< |0_dst-port| 65536))
(assert (< |0_src-port| 65536))
(assert (>= |0_icmp-type| 0))
(assert (>= |0_ip-protocol| 0))
(assert (< |0_icmp-type| 256))
(assert (<= |0_ip-protocol| 256))
(assert (>= |0_icmp-code| 0))
(assert (< |0_icmp-code| 16))
(assert (>= |0_r2_OVERALL_BEST_None_routerID| 0))
(assert (>= |0_r2_OVERALL_BEST_None_med| 0))
(assert (< |0_r2_OVERALL_BEST_None_med| 4294967296))
(assert (>= |0_r2_OVERALL_BEST_None_localPref| 0))
(assert (< |0_r2_OVERALL_BEST_None_localPref| 4294967296))
(assert (>= |0_r2_OVERALL_BEST_None_metric| 0))
(assert (< |0_r2_OVERALL_BEST_None_metric| 65536))
(assert (>= |0_r2_OVERALL_BEST_None_prefixLength| 0))
(assert (<= |0_r2_OVERALL_BEST_None_prefixLength| 32))
(assert (>= |0_r3_OVERALL_BEST_None_routerID| 0))
(assert (>= |0_r3_OVERALL_BEST_None_med| 0))
(assert (< |0_r3_OVERALL_BEST_None_med| 4294967296))
(assert (>= |0_r3_OVERALL_BEST_None_localPref| 0))
(assert (< |0_r3_OVERALL_BEST_None_localPref| 4294967296))
(assert (>= |0_r3_OVERALL_BEST_None_metric| 0))
(assert (< |0_r3_OVERALL_BEST_None_metric| 65536))
(assert (>= |0_r3_OVERALL_BEST_None_prefixLength| 0))
(assert (<= |0_r3_OVERALL_BEST_None_prefixLength| 32))
(assert (>= |0_r4_OVERALL_BEST_None_routerID| 0))
(assert (>= |0_r4_OVERALL_BEST_None_med| 0))
(assert (< |0_r4_OVERALL_BEST_None_med| 4294967296))
(assert (>= |0_r4_OVERALL_BEST_None_localPref| 0))
(assert (< |0_r4_OVERALL_BEST_None_localPref| 4294967296))
(assert (>= |0_r4_OVERALL_BEST_None_metric| 0))
(assert (< |0_r4_OVERALL_BEST_None_metric| 65536))
(assert (>= |0_r4_OVERALL_BEST_None_prefixLength| 0))
(assert (<= |0_r4_OVERALL_BEST_None_prefixLength| 32))
(assert (>= |0_r1_OVERALL_BEST_None_routerID| 0))
(assert (>= |0_r1_OVERALL_BEST_None_adminDist| 0))
(assert (< |0_r1_OVERALL_BEST_None_adminDist| 256))
(assert (>= |0_r1_OVERALL_BEST_None_med| 0))
(assert (< |0_r1_OVERALL_BEST_None_med| 4294967296))
(assert (>= |0_r1_OVERALL_BEST_None_localPref| 0))
(assert (< |0_r1_OVERALL_BEST_None_localPref| 4294967296))
(assert (>= |0_r1_OVERALL_BEST_None_metric| 0))
(assert (< |0_r1_OVERALL_BEST_None_metric| 65536))
(assert (>= |0_r1_OVERALL_BEST_None_prefixLength| 0))
(assert (<= |0_r1_OVERALL_BEST_None_prefixLength| 32))
(assert (>= |0_r1_BGP_BEST_None_routerID| 0))
(assert (>= |0_r1_BGP_BEST_None_med| 0))
(assert (< |0_r1_BGP_BEST_None_med| 4294967296))
(assert (>= |0_r1_BGP_BEST_None_localPref| 0))
(assert (< |0_r1_BGP_BEST_None_localPref| 4294967296))
(assert (>= |0_r1_BGP_BEST_None_metric| 0))
(assert (< |0_r1_BGP_BEST_None_metric| 65536))
(assert (>= |0_r1_BGP_BEST_None_prefixLength| 0))
(assert (<= |0_r1_BGP_BEST_None_prefixLength| 32))
(assert (>= |0_r1_CONNECTED_BEST_None_prefixLength| 0))
(assert (<= |0_r1_CONNECTED_BEST_None_prefixLength| 32))
(assert (>= |0_r2_BGP_EXPORT_Ethernet21_med| 0))
(assert (< |0_r2_BGP_EXPORT_Ethernet21_med| 4294967296))
(assert (>= |0_r2_BGP_EXPORT_Ethernet21_localPref| 0))
(assert (< |0_r2_BGP_EXPORT_Ethernet21_localPref| 4294967296))
(assert (>= |0_r2_BGP_EXPORT_Ethernet21_metric| 0))
(assert (< |0_r2_BGP_EXPORT_Ethernet21_metric| 65536))
(assert (>= |0_r2_BGP_EXPORT_Ethernet21_prefixLength| 0))
(assert (<= |0_r2_BGP_EXPORT_Ethernet21_prefixLength| 32))
(assert (>= |0_r2_BGP_IMPORT_Ethernet21_med| 0))
(assert (< |0_r2_BGP_IMPORT_Ethernet21_med| 4294967296))
(assert (>= |0_r2_BGP_IMPORT_Ethernet21_localPref| 0))
(assert (< |0_r2_BGP_IMPORT_Ethernet21_localPref| 4294967296))
(assert (>= |0_r2_BGP_IMPORT_Ethernet21_metric| 0))
(assert (< |0_r2_BGP_IMPORT_Ethernet21_metric| 65536))
(assert (>= |0_r2_BGP_IMPORT_Ethernet21_prefixLength| 0))
(assert (<= |0_r2_BGP_IMPORT_Ethernet21_prefixLength| 32))
(assert (>= |0_r2_BGP_EXPORT_Ethernet24_med| 0))
(assert (< |0_r2_BGP_EXPORT_Ethernet24_med| 4294967296))
(assert (>= |0_r2_BGP_EXPORT_Ethernet24_localPref| 0))
(assert (< |0_r2_BGP_EXPORT_Ethernet24_localPref| 4294967296))
(assert (>= |0_r2_BGP_EXPORT_Ethernet24_metric| 0))
(assert (< |0_r2_BGP_EXPORT_Ethernet24_metric| 65536))
(assert (>= |0_r2_BGP_EXPORT_Ethernet24_prefixLength| 0))
(assert (<= |0_r2_BGP_EXPORT_Ethernet24_prefixLength| 32))
(assert (>= |0_r3_BGP_EXPORT_Ethernet34_med| 0))
(assert (< |0_r3_BGP_EXPORT_Ethernet34_med| 4294967296))
(assert (>= |0_r3_BGP_EXPORT_Ethernet34_localPref| 0))
(assert (< |0_r3_BGP_EXPORT_Ethernet34_localPref| 4294967296))
(assert (>= |0_r3_BGP_EXPORT_Ethernet34_metric| 0))
(assert (< |0_r3_BGP_EXPORT_Ethernet34_metric| 65536))
(assert (>= |0_r3_BGP_EXPORT_Ethernet34_prefixLength| 0))
(assert (<= |0_r3_BGP_EXPORT_Ethernet34_prefixLength| 32))
(assert (>= |0_r3_BGP_EXPORT_Ethernet31_med| 0))
(assert (< |0_r3_BGP_EXPORT_Ethernet31_med| 4294967296))
(assert (>= |0_r3_BGP_EXPORT_Ethernet31_localPref| 0))
(assert (< |0_r3_BGP_EXPORT_Ethernet31_localPref| 4294967296))
(assert (>= |0_r3_BGP_EXPORT_Ethernet31_metric| 0))
(assert (< |0_r3_BGP_EXPORT_Ethernet31_metric| 65536))
(assert (>= |0_r3_BGP_EXPORT_Ethernet31_prefixLength| 0))
(assert (<= |0_r3_BGP_EXPORT_Ethernet31_prefixLength| 32))
(assert (>= |0_r3_BGP_IMPORT_Ethernet31_med| 0))
(assert (< |0_r3_BGP_IMPORT_Ethernet31_med| 4294967296))
(assert (>= |0_r3_BGP_IMPORT_Ethernet31_localPref| 0))
(assert (< |0_r3_BGP_IMPORT_Ethernet31_localPref| 4294967296))
(assert (>= |0_r3_BGP_IMPORT_Ethernet31_metric| 0))
(assert (< |0_r3_BGP_IMPORT_Ethernet31_metric| 65536))
(assert (>= |0_r3_BGP_IMPORT_Ethernet31_prefixLength| 0))
(assert (<= |0_r3_BGP_IMPORT_Ethernet31_prefixLength| 32))
(assert (>= |0_r4_BGP_SINGLE-EXPORT__med| 0))
(assert (< |0_r4_BGP_SINGLE-EXPORT__med| 4294967296))
(assert (>= |0_r4_BGP_SINGLE-EXPORT__localPref| 0))
(assert (< |0_r4_BGP_SINGLE-EXPORT__localPref| 4294967296))
(assert (>= |0_r4_BGP_SINGLE-EXPORT__metric| 0))
(assert (< |0_r4_BGP_SINGLE-EXPORT__metric| 65536))
(assert (>= |0_r4_BGP_SINGLE-EXPORT__prefixLength| 0))
(assert (<= |0_r4_BGP_SINGLE-EXPORT__prefixLength| 32))
(assert (>= |0_r4_BGP_IMPORT_Ethernet41_med| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet41_med| 4294967296))
(assert (>= |0_r4_BGP_IMPORT_Ethernet41_localPref| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet41_localPref| 4294967296))
(assert (>= |0_r4_BGP_IMPORT_Ethernet41_metric| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet41_metric| 65536))
(assert (>= |0_r4_BGP_IMPORT_Ethernet41_prefixLength| 0))
(assert (<= |0_r4_BGP_IMPORT_Ethernet41_prefixLength| 32))
(assert (>= |0_r4_BGP_IMPORT_Ethernet43_med| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet43_med| 4294967296))
(assert (>= |0_r4_BGP_IMPORT_Ethernet43_localPref| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet43_localPref| 4294967296))
(assert (>= |0_r4_BGP_IMPORT_Ethernet43_metric| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet43_metric| 65536))
(assert (>= |0_r4_BGP_IMPORT_Ethernet43_prefixLength| 0))
(assert (<= |0_r4_BGP_IMPORT_Ethernet43_prefixLength| 32))
(assert (>= |0_r4_BGP_IMPORT_Ethernet42_med| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet42_med| 4294967296))
(assert (>= |0_r4_BGP_IMPORT_Ethernet42_localPref| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet42_localPref| 4294967296))
(assert (>= |0_r4_BGP_IMPORT_Ethernet42_metric| 0))
(assert (< |0_r4_BGP_IMPORT_Ethernet42_metric| 65536))
(assert (>= |0_r4_BGP_IMPORT_Ethernet42_prefixLength| 0))
(assert (<= |0_r4_BGP_IMPORT_Ethernet42_prefixLength| 32))
(assert (>= |0_r1_BGP_EXPORT_Ethernet12_med| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet12_med| 4294967296))
(assert (>= |0_r1_BGP_EXPORT_Ethernet12_localPref| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet12_localPref| 4294967296))
(assert (>= |0_r1_BGP_EXPORT_Ethernet12_metric| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet12_metric| 65536))
(assert (>= |0_r1_BGP_EXPORT_Ethernet12_prefixLength| 0))
(assert (<= |0_r1_BGP_EXPORT_Ethernet12_prefixLength| 32))
(assert (>= |0_r1_BGP_EXPORT_Ethernet13_med| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet13_med| 4294967296))
(assert (>= |0_r1_BGP_EXPORT_Ethernet13_localPref| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet13_localPref| 4294967296))
(assert (>= |0_r1_BGP_EXPORT_Ethernet13_metric| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet13_metric| 65536))
(assert (>= |0_r1_BGP_EXPORT_Ethernet13_prefixLength| 0))
(assert (<= |0_r1_BGP_EXPORT_Ethernet13_prefixLength| 32))
(assert (>= |0_r1_BGP_EXPORT_Ethernet14_med| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet14_med| 4294967296))
(assert (>= |0_r1_BGP_EXPORT_Ethernet14_localPref| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet14_localPref| 4294967296))
(assert (>= |0_r1_BGP_EXPORT_Ethernet14_metric| 0))
(assert (< |0_r1_BGP_EXPORT_Ethernet14_metric| 65536))
(assert (>= |0_r1_BGP_EXPORT_Ethernet14_prefixLength| 0))
(assert (<= |0_r1_BGP_EXPORT_Ethernet14_prefixLength| 32))
(assert (>= |0_r1_CONNECTED_IMPORT_Loopback0_prefixLength| 0))
(assert (<= |0_r1_CONNECTED_IMPORT_Loopback0_prefixLength| 32))
(assert (let ((a!1 (ite true
                (ite true
                     (and (= |0_r2_BGP_IMPORT_Ethernet21_permitted|
                             |0_r1_BGP_EXPORT_Ethernet12_permitted|)
                          (= |0_r2_BGP_IMPORT_Ethernet21_prefixLength|
                             |0_r1_BGP_EXPORT_Ethernet12_prefixLength|)
                          true
                          (= |0_r2_BGP_IMPORT_Ethernet21_med|
                             |0_r1_BGP_EXPORT_Ethernet12_med|)
                          (= |0_r2_BGP_IMPORT_Ethernet21_localPref|
                             |0_r1_BGP_EXPORT_Ethernet12_localPref|)
                          (= |0_r2_BGP_IMPORT_Ethernet21_metric|
                             |0_r1_BGP_EXPORT_Ethernet12_metric|)
                          true
                          true
                          true
                          true
                          true
                          true
                          true
                          true)
                     (not |0_r2_BGP_IMPORT_Ethernet21_permitted|))
                (not |0_r2_BGP_IMPORT_Ethernet21_permitted|))))
  (ite (and (not |0_CONTROL-FORWARDING_r1_Ethernet12|)
            true
            |0_r1_BGP_EXPORT_Ethernet12_permitted|
            (= |0_FAILED-EDGE_r1_r2| 0)
            (= |0_FAILED-NODE_r2| 0))
       a!1
       (not |0_r2_BGP_IMPORT_Ethernet21_permitted|))))
(assert (let ((a!1 (and (= |0_r2_BGP_EXPORT_Ethernet21_permitted|
                   |0_r2_OVERALL_BEST_None_permitted|)
                (= |0_r2_BGP_EXPORT_Ethernet21_prefixLength|
                   |0_r2_OVERALL_BEST_None_prefixLength|)
                true
                (= |0_r2_BGP_EXPORT_Ethernet21_med| 0)
                (= |0_r2_BGP_EXPORT_Ethernet21_localPref| 100)
                (= |0_r2_BGP_EXPORT_Ethernet21_metric|
                   (ite true (+ |0_r2_OVERALL_BEST_None_metric| 1) 1))
                true
                true
                true
                true
                true
                true
                true
                true)))
  (ite (and true
            true
            |0_r2_OVERALL_BEST_None_permitted|
            (= |0_FAILED-EDGE_r1_r2| 0)
            (= |0_FAILED-NODE_r1| 0))
       (ite true
            (ite true a!1 (not |0_r2_BGP_EXPORT_Ethernet21_permitted|))
            (not |0_r2_BGP_EXPORT_Ethernet21_permitted|))
       (not |0_r2_BGP_EXPORT_Ethernet21_permitted|))))
(assert (let ((a!1 (and (= |0_r2_BGP_EXPORT_Ethernet24_permitted|
                   |0_r2_OVERALL_BEST_None_permitted|)
                (= |0_r2_BGP_EXPORT_Ethernet24_prefixLength|
                   |0_r2_OVERALL_BEST_None_prefixLength|)
                true
                (= |0_r2_BGP_EXPORT_Ethernet24_med| 0)
                (= |0_r2_BGP_EXPORT_Ethernet24_localPref| 100)
                (= |0_r2_BGP_EXPORT_Ethernet24_metric|
                   (ite true (+ |0_r2_OVERALL_BEST_None_metric| 1) 1))
                true
                true
                true
                true
                true
                true
                true
                true)))
  (ite (and true
            true
            |0_r2_OVERALL_BEST_None_permitted|
            (= |0_FAILED-EDGE_r2_r4| 0)
            (= |0_FAILED-NODE_r4| 0))
       (ite true
            (ite true a!1 (not |0_r2_BGP_EXPORT_Ethernet24_permitted|))
            (not |0_r2_BGP_EXPORT_Ethernet24_permitted|))
       (not |0_r2_BGP_EXPORT_Ethernet24_permitted|))))
(assert (let ((a!1 (and (= |0_r3_BGP_EXPORT_Ethernet34_permitted|
                   |0_r3_OVERALL_BEST_None_permitted|)
                (= |0_r3_BGP_EXPORT_Ethernet34_prefixLength|
                   |0_r3_OVERALL_BEST_None_prefixLength|)
                true
                (= |0_r3_BGP_EXPORT_Ethernet34_med| 0)
                (= |0_r3_BGP_EXPORT_Ethernet34_localPref| 100)
                (= |0_r3_BGP_EXPORT_Ethernet34_metric|
                   (ite true (+ |0_r3_OVERALL_BEST_None_metric| 1) 1))
                true
                true
                true
                true
                true
                true
                true
                true)))
  (ite (and true
            true
            |0_r3_OVERALL_BEST_None_permitted|
            (= |0_FAILED-EDGE_r3_r4| 0)
            (= |0_FAILED-NODE_r4| 0))
       (ite true
            (ite true a!1 (not |0_r3_BGP_EXPORT_Ethernet34_permitted|))
            (not |0_r3_BGP_EXPORT_Ethernet34_permitted|))
       (not |0_r3_BGP_EXPORT_Ethernet34_permitted|))))
(assert (let ((a!1 (ite true
                (ite true
                     (and (= |0_r3_BGP_IMPORT_Ethernet31_permitted|
                             |0_r1_BGP_EXPORT_Ethernet13_permitted|)
                          (= |0_r3_BGP_IMPORT_Ethernet31_prefixLength|
                             |0_r1_BGP_EXPORT_Ethernet13_prefixLength|)
                          true
                          (= |0_r3_BGP_IMPORT_Ethernet31_med|
                             |0_r1_BGP_EXPORT_Ethernet13_med|)
                          (= |0_r3_BGP_IMPORT_Ethernet31_localPref|
                             |0_r1_BGP_EXPORT_Ethernet13_localPref|)
                          (= |0_r3_BGP_IMPORT_Ethernet31_metric|
                             |0_r1_BGP_EXPORT_Ethernet13_metric|)
                          true
                          true
                          true
                          true
                          true
                          true
                          true
                          true)
                     (not |0_r3_BGP_IMPORT_Ethernet31_permitted|))
                (not |0_r3_BGP_IMPORT_Ethernet31_permitted|))))
  (ite (and (not |0_CONTROL-FORWARDING_r1_Ethernet13|)
            true
            |0_r1_BGP_EXPORT_Ethernet13_permitted|
            (= |0_FAILED-EDGE_r1_r3| 0)
            (= |0_FAILED-NODE_r3| 0))
       a!1
       (not |0_r3_BGP_IMPORT_Ethernet31_permitted|))))
(assert (let ((a!1 (and (= |0_r3_BGP_EXPORT_Ethernet31_permitted|
                   |0_r3_OVERALL_BEST_None_permitted|)
                (= |0_r3_BGP_EXPORT_Ethernet31_prefixLength|
                   |0_r3_OVERALL_BEST_None_prefixLength|)
                true
                (= |0_r3_BGP_EXPORT_Ethernet31_med| 0)
                (= |0_r3_BGP_EXPORT_Ethernet31_localPref| 100)
                (= |0_r3_BGP_EXPORT_Ethernet31_metric|
                   (ite true (+ |0_r3_OVERALL_BEST_None_metric| 1) 1))
                true
                true
                true
                true
                true
                true
                true
                true)))
  (ite (and true
            true
            |0_r3_OVERALL_BEST_None_permitted|
            (= |0_FAILED-EDGE_r1_r3| 0)
            (= |0_FAILED-NODE_r1| 0))
       (ite true
            (ite true a!1 (not |0_r3_BGP_EXPORT_Ethernet31_permitted|))
            (not |0_r3_BGP_EXPORT_Ethernet31_permitted|))
       (not |0_r3_BGP_EXPORT_Ethernet31_permitted|))))
(assert (let ((a!1 (= (bvnot (bvor (bvnot |0_dst-ip|)
                           (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__mask)))
              (bvnot (bvor (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__ip)
                           (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__mask))))))
(let ((a!2 (and (or (not Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line1__match_prefixlist_enable)
                    (and Config_r4_RouteFilterList_pl__Line1__10_0_0_0__enable
                         (= |0_r1_BGP_EXPORT_Ethernet14_prefixLength|
                            Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start)
                         (= |0_r1_BGP_EXPORT_Ethernet14_prefixLength|
                            Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end)
                         a!1
                         Config_r4_RouteFilterList_pl__Line1__10_0_0_0__action))
                Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line1__match_prefixlist_enable)))
(let ((a!3 (ite true
                (and (= |0_r4_BGP_IMPORT_Ethernet41_permitted|
                        |0_r1_BGP_EXPORT_Ethernet14_permitted|)
                     (= |0_r4_BGP_IMPORT_Ethernet41_prefixLength|
                        |0_r1_BGP_EXPORT_Ethernet14_prefixLength|)
                     true
                     (= |0_r4_BGP_IMPORT_Ethernet41_med|
                        |0_r1_BGP_EXPORT_Ethernet14_med|)
                     (= |0_r4_BGP_IMPORT_Ethernet41_localPref|
                        (ite a!2
                             Config_r4_RoutingPolicy_R4_IN_FROM_R1__Seq10__Line2__set_localpreference_100
                             |0_r1_BGP_EXPORT_Ethernet14_localPref|))
                     (= |0_r4_BGP_IMPORT_Ethernet41_metric|
                        |0_r1_BGP_EXPORT_Ethernet14_metric|)
                     true
                     true
                     true
                     true
                     true
                     true
                     true
                     true)
                (not |0_r4_BGP_IMPORT_Ethernet41_permitted|))))
  (ite (and (not |0_CONTROL-FORWARDING_r1_Ethernet14|)
            true
            |0_r1_BGP_EXPORT_Ethernet14_permitted|
            (= |0_FAILED-EDGE_r1_r4| 0)
            (= |0_FAILED-NODE_r4| 0))
       (ite a!2 a!3 (not |0_r4_BGP_IMPORT_Ethernet41_permitted|))
       (not |0_r4_BGP_IMPORT_Ethernet41_permitted|))))))
(assert (let ((a!1 (and (= |0_r4_BGP_SINGLE-EXPORT__permitted|
                   |0_r4_OVERALL_BEST_None_permitted|)
                (= |0_r4_BGP_SINGLE-EXPORT__prefixLength|
                   |0_r4_OVERALL_BEST_None_prefixLength|)
                true
                (= |0_r4_BGP_SINGLE-EXPORT__med| 0)
                (= |0_r4_BGP_SINGLE-EXPORT__localPref| 100)
                (= |0_r4_BGP_SINGLE-EXPORT__metric|
                   (ite true (+ |0_r4_OVERALL_BEST_None_metric| 1) 1))
                true
                true
                true
                true
                true
                true
                true
                true)))
  (ite (and true
            true
            |0_r4_OVERALL_BEST_None_permitted|
            (= |0_FAILED-EDGE_r1_r4| 0)
            (= |0_FAILED-NODE_r1| 0))
       (ite true
            (ite true a!1 (not |0_r4_BGP_SINGLE-EXPORT__permitted|))
            (not |0_r4_BGP_SINGLE-EXPORT__permitted|))
       (not |0_r4_BGP_SINGLE-EXPORT__permitted|))))
(assert (let ((a!1 (= (bvnot (bvor (bvnot |0_dst-ip|)
                           (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__mask)))
              (bvnot (bvor (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__ip)
                           (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__mask))))))
(let ((a!2 (and (or (not Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line1__match_prefixlist_enable)
                    (and Config_r4_RouteFilterList_pl__Line1__10_0_0_0__enable
                         (= |0_r3_BGP_EXPORT_Ethernet34_prefixLength|
                            Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start)
                         (= |0_r3_BGP_EXPORT_Ethernet34_prefixLength|
                            Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end)
                         a!1
                         Config_r4_RouteFilterList_pl__Line1__10_0_0_0__action))
                Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line1__match_prefixlist_enable)))
(let ((a!3 (ite true
                (and (= |0_r4_BGP_IMPORT_Ethernet43_permitted|
                        |0_r3_BGP_EXPORT_Ethernet34_permitted|)
                     (= |0_r4_BGP_IMPORT_Ethernet43_prefixLength|
                        |0_r3_BGP_EXPORT_Ethernet34_prefixLength|)
                     true
                     (= |0_r4_BGP_IMPORT_Ethernet43_med|
                        |0_r3_BGP_EXPORT_Ethernet34_med|)
                     (= |0_r4_BGP_IMPORT_Ethernet43_localPref|
                        (ite a!2
                             Config_r4_RoutingPolicy_R4_IN_FROM_R3__Seq10__Line2__set_localpreference_50
                             |0_r3_BGP_EXPORT_Ethernet34_localPref|))
                     (= |0_r4_BGP_IMPORT_Ethernet43_metric|
                        |0_r3_BGP_EXPORT_Ethernet34_metric|)
                     true
                     true
                     true
                     true
                     true
                     true
                     true
                     true)
                (not |0_r4_BGP_IMPORT_Ethernet43_permitted|))))
  (ite (and (not |0_CONTROL-FORWARDING_r3_Ethernet34|)
            true
            |0_r3_BGP_EXPORT_Ethernet34_permitted|
            (= |0_FAILED-EDGE_r3_r4| 0)
            (= |0_FAILED-NODE_r4| 0))
       (ite a!2 a!3 (not |0_r4_BGP_IMPORT_Ethernet43_permitted|))
       (not |0_r4_BGP_IMPORT_Ethernet43_permitted|))))))
(assert (let ((a!1 (= (bvnot (bvor (bvnot |0_dst-ip|)
                           (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__mask)))
              (bvnot (bvor (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__ip)
                           (bvnot Config_r4_RouteFilterList_pl__Line1__10_0_0_0__mask))))))
(let ((a!2 (and (or (not Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line1__match_prefixlist_enable)
                    (and Config_r4_RouteFilterList_pl__Line1__10_0_0_0__enable
                         (= |0_r2_BGP_EXPORT_Ethernet24_prefixLength|
                            Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start)
                         (= |0_r2_BGP_EXPORT_Ethernet24_prefixLength|
                            Config_r4_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end)
                         a!1
                         Config_r4_RouteFilterList_pl__Line1__10_0_0_0__action))
                Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line1__match_prefixlist_enable)))
(let ((a!3 (ite true
                (and (= |0_r4_BGP_IMPORT_Ethernet42_permitted|
                        |0_r2_BGP_EXPORT_Ethernet24_permitted|)
                     (= |0_r4_BGP_IMPORT_Ethernet42_prefixLength|
                        |0_r2_BGP_EXPORT_Ethernet24_prefixLength|)
                     true
                     (= |0_r4_BGP_IMPORT_Ethernet42_med|
                        |0_r2_BGP_EXPORT_Ethernet24_med|)
                     (= |0_r4_BGP_IMPORT_Ethernet42_localPref|
                        (ite a!2
                             Config_r4_RoutingPolicy_R4_IN_FROM_R2__Seq10__Line2__set_localpreference_200
                             |0_r2_BGP_EXPORT_Ethernet24_localPref|))
                     (= |0_r4_BGP_IMPORT_Ethernet42_metric|
                        |0_r2_BGP_EXPORT_Ethernet24_metric|)
                     true
                     true
                     true
                     true
                     true
                     true
                     true
                     true)
                (not |0_r4_BGP_IMPORT_Ethernet42_permitted|))))
  (ite (and (not |0_CONTROL-FORWARDING_r2_Ethernet24|)
            true
            |0_r2_BGP_EXPORT_Ethernet24_permitted|
            (= |0_FAILED-EDGE_r2_r4| 0)
            (= |0_FAILED-NODE_r4| 0))
       (ite a!2 a!3 (not |0_r4_BGP_IMPORT_Ethernet42_permitted|))
       (not |0_r4_BGP_IMPORT_Ethernet42_permitted|))))))
(assert (let ((a!1 (= (bvnot (bvor (bvnot |0_dst-ip|)
                           (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__mask)))
              (bvnot (bvor (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__ip)
                           (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__mask)))))
      (a!3 (and (= |0_r1_BGP_EXPORT_Ethernet12_permitted|
                   |0_r1_OVERALL_BEST_None_permitted|)
                (= |0_r1_BGP_EXPORT_Ethernet12_prefixLength|
                   |0_r1_OVERALL_BEST_None_prefixLength|)
                true
                (= |0_r1_BGP_EXPORT_Ethernet12_med| 0)
                (= |0_r1_BGP_EXPORT_Ethernet12_localPref| 100)
                (= |0_r1_BGP_EXPORT_Ethernet12_metric|
                   (ite (= |0_r1_OVERALL_BEST_None_history| #b0)
                        (+ |0_r1_OVERALL_BEST_None_metric| 1)
                        1))
                true
                true
                true
                true
                true
                true
                true
                true)))
(let ((a!2 (and (= |0_r1_OVERALL_BEST_None_history| #b1)
                (or (not Config_r1_RoutingPolicy_REDISTRIBUTE_CONNECTED__Seq10__Line1__match_prefixlist_enable)
                    (and Config_r1_RouteFilterList_pl__Line1__10_0_0_0__enable
                         (= |0_r1_OVERALL_BEST_None_prefixLength|
                            Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start)
                         (= |0_r1_OVERALL_BEST_None_prefixLength|
                            Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end)
                         a!1
                         Config_r1_RouteFilterList_pl__Line1__10_0_0_0__action))
                Config_r1_RoutingPolicy_REDISTRIBUTE_CONNECTED__Seq10__Line1__match_prefixlist_enable)))
  (ite (and true
            true
            |0_r1_OVERALL_BEST_None_permitted|
            (= |0_FAILED-EDGE_r1_r2| 0)
            (= |0_FAILED-NODE_r2| 0))
       (ite (or (= |0_r1_OVERALL_BEST_None_history| #b0) a!2)
            (ite true a!3 (not |0_r1_BGP_EXPORT_Ethernet12_permitted|))
            (not |0_r1_BGP_EXPORT_Ethernet12_permitted|))
       (not |0_r1_BGP_EXPORT_Ethernet12_permitted|)))))
(assert (let ((a!1 (= (bvnot (bvor (bvnot |0_dst-ip|)
                           (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__mask)))
              (bvnot (bvor (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__ip)
                           (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__mask)))))
      (a!3 (and (= |0_r1_BGP_EXPORT_Ethernet13_permitted|
                   |0_r1_OVERALL_BEST_None_permitted|)
                (= |0_r1_BGP_EXPORT_Ethernet13_prefixLength|
                   |0_r1_OVERALL_BEST_None_prefixLength|)
                true
                (= |0_r1_BGP_EXPORT_Ethernet13_med| 0)
                (= |0_r1_BGP_EXPORT_Ethernet13_localPref| 100)
                (= |0_r1_BGP_EXPORT_Ethernet13_metric|
                   (ite (= |0_r1_OVERALL_BEST_None_history| #b0)
                        (+ |0_r1_OVERALL_BEST_None_metric| 1)
                        1))
                true
                true
                true
                true
                true
                true
                true
                true)))
(let ((a!2 (and (= |0_r1_OVERALL_BEST_None_history| #b1)
                (or (not Config_r1_RoutingPolicy_REDISTRIBUTE_CONNECTED__Seq10__Line1__match_prefixlist_enable)
                    (and Config_r1_RouteFilterList_pl__Line1__10_0_0_0__enable
                         (= |0_r1_OVERALL_BEST_None_prefixLength|
                            Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start)
                         (= |0_r1_OVERALL_BEST_None_prefixLength|
                            Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end)
                         a!1
                         Config_r1_RouteFilterList_pl__Line1__10_0_0_0__action))
                Config_r1_RoutingPolicy_REDISTRIBUTE_CONNECTED__Seq10__Line1__match_prefixlist_enable)))
  (ite (and true
            true
            |0_r1_OVERALL_BEST_None_permitted|
            (= |0_FAILED-EDGE_r1_r3| 0)
            (= |0_FAILED-NODE_r3| 0))
       (ite (or (= |0_r1_OVERALL_BEST_None_history| #b0) a!2)
            (ite true a!3 (not |0_r1_BGP_EXPORT_Ethernet13_permitted|))
            (not |0_r1_BGP_EXPORT_Ethernet13_permitted|))
       (not |0_r1_BGP_EXPORT_Ethernet13_permitted|)))))
(assert (let ((a!1 (= (bvnot (bvor (bvnot |0_dst-ip|)
                           (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__mask)))
              (bvnot (bvor (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__ip)
                           (bvnot Config_r1_RouteFilterList_pl__Line1__10_0_0_0__mask)))))
      (a!3 (and (= |0_r1_BGP_EXPORT_Ethernet14_permitted|
                   |0_r1_OVERALL_BEST_None_permitted|)
                (= |0_r1_BGP_EXPORT_Ethernet14_prefixLength|
                   |0_r1_OVERALL_BEST_None_prefixLength|)
                true
                (= |0_r1_BGP_EXPORT_Ethernet14_med| 0)
                (= |0_r1_BGP_EXPORT_Ethernet14_localPref| 100)
                (= |0_r1_BGP_EXPORT_Ethernet14_metric|
                   (ite (= |0_r1_OVERALL_BEST_None_history| #b0)
                        (+ |0_r1_OVERALL_BEST_None_metric| 1)
                        1))
                true
                true
                true
                true
                true
                true
                true
                true)))
(let ((a!2 (and (= |0_r1_OVERALL_BEST_None_history| #b1)
                (or (not Config_r1_RoutingPolicy_REDISTRIBUTE_CONNECTED__Seq10__Line1__match_prefixlist_enable)
                    (and Config_r1_RouteFilterList_pl__Line1__10_0_0_0__enable
                         (= |0_r1_OVERALL_BEST_None_prefixLength|
                            Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_start)
                         (= |0_r1_OVERALL_BEST_None_prefixLength|
                            Config_r1_RouteFilterList_pl__Line1__10_0_0_0__prefix_range_end)
                         a!1
                         Config_r1_RouteFilterList_pl__Line1__10_0_0_0__action))
                Config_r1_RoutingPolicy_REDISTRIBUTE_CONNECTED__Seq10__Line1__match_prefixlist_enable)))
  (ite (and true
            true
            |0_r1_OVERALL_BEST_None_permitted|
            (= |0_FAILED-EDGE_r1_r4| 0)
            (= |0_FAILED-NODE_r4| 0))
       (ite (or (= |0_r1_OVERALL_BEST_None_history| #b0) a!2)
            (ite true a!3 (not |0_r1_BGP_EXPORT_Ethernet14_permitted|))
            (not |0_r1_BGP_EXPORT_Ethernet14_permitted|))
       (not |0_r1_BGP_EXPORT_Ethernet14_permitted|)))))
(assert (not |0_r1_CONNECTED_BEST_None_permitted|))
(assert (=> |0_r2_OVERALL_BEST_None_permitted| true))
(assert (=> |0_r3_OVERALL_BEST_None_permitted| true))
(assert (=> |0_r4_OVERALL_BEST_None_permitted| true))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r2_OVERALL_BEST_None_routerID| 16843009))))))
(let ((a!2 (and (= |0_r2_OVERALL_BEST_None_med|
                   |0_r2_BGP_IMPORT_Ethernet21_med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r2_OVERALL_BEST_None_metric|
                  |0_r2_BGP_IMPORT_Ethernet21_metric|)
               (and (= |0_r2_OVERALL_BEST_None_metric|
                       |0_r2_BGP_IMPORT_Ethernet21_metric|)
                    (or (< |0_r2_OVERALL_BEST_None_med|
                           |0_r2_BGP_IMPORT_Ethernet21_med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r2_OVERALL_BEST_None_localPref|
                       |0_r2_BGP_IMPORT_Ethernet21_localPref|)
                    (and (= |0_r2_OVERALL_BEST_None_localPref|
                            |0_r2_BGP_IMPORT_Ethernet21_localPref|)
                         a!3)))))
  (=> |0_r2_BGP_IMPORT_Ethernet21_permitted|
      (or (> |0_r2_OVERALL_BEST_None_prefixLength|
             |0_r2_BGP_IMPORT_Ethernet21_prefixLength|)
          (and (= |0_r2_OVERALL_BEST_None_prefixLength|
                  |0_r2_BGP_IMPORT_Ethernet21_prefixLength|)
               (or false a!4)))))))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r2_OVERALL_BEST_None_routerID| 67372036))))))
(let ((a!2 (and (= |0_r2_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r2_OVERALL_BEST_None_metric|
                  |0_r4_BGP_SINGLE-EXPORT__metric|)
               (and (= |0_r2_OVERALL_BEST_None_metric|
                       |0_r4_BGP_SINGLE-EXPORT__metric|)
                    (or (< |0_r2_OVERALL_BEST_None_med|
                           |0_r4_BGP_SINGLE-EXPORT__med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r2_OVERALL_BEST_None_localPref|
                       |0_r4_BGP_SINGLE-EXPORT__localPref|)
                    (and (= |0_r2_OVERALL_BEST_None_localPref|
                            |0_r4_BGP_SINGLE-EXPORT__localPref|)
                         a!3)))))
  (=> |0_r4_BGP_SINGLE-EXPORT__permitted|
      (or (> |0_r2_OVERALL_BEST_None_prefixLength|
             |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
          (and (= |0_r2_OVERALL_BEST_None_prefixLength|
                  |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
               (or false a!4)))))))))
(assert (= (or |0_r2_BGP_IMPORT_Ethernet21_permitted|
       |0_r4_BGP_SINGLE-EXPORT__permitted|)
   |0_r2_OVERALL_BEST_None_permitted|))
(assert (=> (or |0_r2_BGP_IMPORT_Ethernet21_permitted|
        |0_r4_BGP_SINGLE-EXPORT__permitted|)
    (or (and |0_r2_BGP_IMPORT_Ethernet21_permitted|
             (= |0_r2_OVERALL_BEST_None_prefixLength|
                |0_r2_BGP_IMPORT_Ethernet21_prefixLength|)
             true
             (= |0_r2_OVERALL_BEST_None_localPref|
                |0_r2_BGP_IMPORT_Ethernet21_localPref|)
             (= |0_r2_OVERALL_BEST_None_metric|
                |0_r2_BGP_IMPORT_Ethernet21_metric|)
             (= |0_r2_OVERALL_BEST_None_med| |0_r2_BGP_IMPORT_Ethernet21_med|)
             true
             true
             (= |0_r2_OVERALL_BEST_None_routerID| 16843009)
             true
             true
             true
             true
             true)
        (and |0_r4_BGP_SINGLE-EXPORT__permitted|
             (= |0_r2_OVERALL_BEST_None_prefixLength|
                |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
             true
             (= |0_r2_OVERALL_BEST_None_localPref|
                |0_r4_BGP_SINGLE-EXPORT__localPref|)
             (= |0_r2_OVERALL_BEST_None_metric|
                |0_r4_BGP_SINGLE-EXPORT__metric|)
             (= |0_r2_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
             true
             true
             (= |0_r2_OVERALL_BEST_None_routerID| 67372036)
             true
             true
             true
             true
             true))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r3_OVERALL_BEST_None_routerID| 16843009))))))
(let ((a!2 (and (= |0_r3_OVERALL_BEST_None_med|
                   |0_r3_BGP_IMPORT_Ethernet31_med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r3_OVERALL_BEST_None_metric|
                  |0_r3_BGP_IMPORT_Ethernet31_metric|)
               (and (= |0_r3_OVERALL_BEST_None_metric|
                       |0_r3_BGP_IMPORT_Ethernet31_metric|)
                    (or (< |0_r3_OVERALL_BEST_None_med|
                           |0_r3_BGP_IMPORT_Ethernet31_med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r3_OVERALL_BEST_None_localPref|
                       |0_r3_BGP_IMPORT_Ethernet31_localPref|)
                    (and (= |0_r3_OVERALL_BEST_None_localPref|
                            |0_r3_BGP_IMPORT_Ethernet31_localPref|)
                         a!3)))))
  (=> |0_r3_BGP_IMPORT_Ethernet31_permitted|
      (or (> |0_r3_OVERALL_BEST_None_prefixLength|
             |0_r3_BGP_IMPORT_Ethernet31_prefixLength|)
          (and (= |0_r3_OVERALL_BEST_None_prefixLength|
                  |0_r3_BGP_IMPORT_Ethernet31_prefixLength|)
               (or false a!4)))))))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r3_OVERALL_BEST_None_routerID| 67372036))))))
(let ((a!2 (and (= |0_r3_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r3_OVERALL_BEST_None_metric|
                  |0_r4_BGP_SINGLE-EXPORT__metric|)
               (and (= |0_r3_OVERALL_BEST_None_metric|
                       |0_r4_BGP_SINGLE-EXPORT__metric|)
                    (or (< |0_r3_OVERALL_BEST_None_med|
                           |0_r4_BGP_SINGLE-EXPORT__med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r3_OVERALL_BEST_None_localPref|
                       |0_r4_BGP_SINGLE-EXPORT__localPref|)
                    (and (= |0_r3_OVERALL_BEST_None_localPref|
                            |0_r4_BGP_SINGLE-EXPORT__localPref|)
                         a!3)))))
  (=> |0_r4_BGP_SINGLE-EXPORT__permitted|
      (or (> |0_r3_OVERALL_BEST_None_prefixLength|
             |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
          (and (= |0_r3_OVERALL_BEST_None_prefixLength|
                  |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
               (or false a!4)))))))))
(assert (= (or |0_r3_BGP_IMPORT_Ethernet31_permitted|
       |0_r4_BGP_SINGLE-EXPORT__permitted|)
   |0_r3_OVERALL_BEST_None_permitted|))
(assert (=> (or |0_r3_BGP_IMPORT_Ethernet31_permitted|
        |0_r4_BGP_SINGLE-EXPORT__permitted|)
    (or (and |0_r3_BGP_IMPORT_Ethernet31_permitted|
             (= |0_r3_OVERALL_BEST_None_prefixLength|
                |0_r3_BGP_IMPORT_Ethernet31_prefixLength|)
             true
             (= |0_r3_OVERALL_BEST_None_localPref|
                |0_r3_BGP_IMPORT_Ethernet31_localPref|)
             (= |0_r3_OVERALL_BEST_None_metric|
                |0_r3_BGP_IMPORT_Ethernet31_metric|)
             (= |0_r3_OVERALL_BEST_None_med| |0_r3_BGP_IMPORT_Ethernet31_med|)
             true
             true
             (= |0_r3_OVERALL_BEST_None_routerID| 16843009)
             true
             true
             true
             true
             true)
        (and |0_r4_BGP_SINGLE-EXPORT__permitted|
             (= |0_r3_OVERALL_BEST_None_prefixLength|
                |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
             true
             (= |0_r3_OVERALL_BEST_None_localPref|
                |0_r4_BGP_SINGLE-EXPORT__localPref|)
             (= |0_r3_OVERALL_BEST_None_metric|
                |0_r4_BGP_SINGLE-EXPORT__metric|)
             (= |0_r3_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
             true
             true
             (= |0_r3_OVERALL_BEST_None_routerID| 67372036)
             true
             true
             true
             true
             true))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r4_OVERALL_BEST_None_routerID| 16843009))))))
(let ((a!2 (and (= |0_r4_OVERALL_BEST_None_med|
                   |0_r4_BGP_IMPORT_Ethernet41_med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r4_OVERALL_BEST_None_metric|
                  |0_r4_BGP_IMPORT_Ethernet41_metric|)
               (and (= |0_r4_OVERALL_BEST_None_metric|
                       |0_r4_BGP_IMPORT_Ethernet41_metric|)
                    (or (< |0_r4_OVERALL_BEST_None_med|
                           |0_r4_BGP_IMPORT_Ethernet41_med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r4_OVERALL_BEST_None_localPref|
                       |0_r4_BGP_IMPORT_Ethernet41_localPref|)
                    (and (= |0_r4_OVERALL_BEST_None_localPref|
                            |0_r4_BGP_IMPORT_Ethernet41_localPref|)
                         a!3)))))
  (=> |0_r4_BGP_IMPORT_Ethernet41_permitted|
      (or (> |0_r4_OVERALL_BEST_None_prefixLength|
             |0_r4_BGP_IMPORT_Ethernet41_prefixLength|)
          (and (= |0_r4_OVERALL_BEST_None_prefixLength|
                  |0_r4_BGP_IMPORT_Ethernet41_prefixLength|)
               (or false a!4)))))))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r4_OVERALL_BEST_None_routerID| 50529027))))))
(let ((a!2 (and (= |0_r4_OVERALL_BEST_None_med|
                   |0_r4_BGP_IMPORT_Ethernet43_med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r4_OVERALL_BEST_None_metric|
                  |0_r4_BGP_IMPORT_Ethernet43_metric|)
               (and (= |0_r4_OVERALL_BEST_None_metric|
                       |0_r4_BGP_IMPORT_Ethernet43_metric|)
                    (or (< |0_r4_OVERALL_BEST_None_med|
                           |0_r4_BGP_IMPORT_Ethernet43_med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r4_OVERALL_BEST_None_localPref|
                       |0_r4_BGP_IMPORT_Ethernet43_localPref|)
                    (and (= |0_r4_OVERALL_BEST_None_localPref|
                            |0_r4_BGP_IMPORT_Ethernet43_localPref|)
                         a!3)))))
  (=> |0_r4_BGP_IMPORT_Ethernet43_permitted|
      (or (> |0_r4_OVERALL_BEST_None_prefixLength|
             |0_r4_BGP_IMPORT_Ethernet43_prefixLength|)
          (and (= |0_r4_OVERALL_BEST_None_prefixLength|
                  |0_r4_BGP_IMPORT_Ethernet43_prefixLength|)
               (or false a!4)))))))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r4_OVERALL_BEST_None_routerID| 33686018))))))
(let ((a!2 (and (= |0_r4_OVERALL_BEST_None_med|
                   |0_r4_BGP_IMPORT_Ethernet42_med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r4_OVERALL_BEST_None_metric|
                  |0_r4_BGP_IMPORT_Ethernet42_metric|)
               (and (= |0_r4_OVERALL_BEST_None_metric|
                       |0_r4_BGP_IMPORT_Ethernet42_metric|)
                    (or (< |0_r4_OVERALL_BEST_None_med|
                           |0_r4_BGP_IMPORT_Ethernet42_med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r4_OVERALL_BEST_None_localPref|
                       |0_r4_BGP_IMPORT_Ethernet42_localPref|)
                    (and (= |0_r4_OVERALL_BEST_None_localPref|
                            |0_r4_BGP_IMPORT_Ethernet42_localPref|)
                         a!3)))))
  (=> |0_r4_BGP_IMPORT_Ethernet42_permitted|
      (or (> |0_r4_OVERALL_BEST_None_prefixLength|
             |0_r4_BGP_IMPORT_Ethernet42_prefixLength|)
          (and (= |0_r4_OVERALL_BEST_None_prefixLength|
                  |0_r4_BGP_IMPORT_Ethernet42_prefixLength|)
               (or false a!4)))))))))
(assert (= (or |0_r4_BGP_IMPORT_Ethernet41_permitted|
       |0_r4_BGP_IMPORT_Ethernet43_permitted|
       |0_r4_BGP_IMPORT_Ethernet42_permitted|)
   |0_r4_OVERALL_BEST_None_permitted|))
(assert (=> (or |0_r4_BGP_IMPORT_Ethernet41_permitted|
        |0_r4_BGP_IMPORT_Ethernet43_permitted|
        |0_r4_BGP_IMPORT_Ethernet42_permitted|)
    (or (and |0_r4_BGP_IMPORT_Ethernet41_permitted|
             (= |0_r4_OVERALL_BEST_None_prefixLength|
                |0_r4_BGP_IMPORT_Ethernet41_prefixLength|)
             true
             (= |0_r4_OVERALL_BEST_None_localPref|
                |0_r4_BGP_IMPORT_Ethernet41_localPref|)
             (= |0_r4_OVERALL_BEST_None_metric|
                |0_r4_BGP_IMPORT_Ethernet41_metric|)
             (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet41_med|)
             true
             true
             (= |0_r4_OVERALL_BEST_None_routerID| 16843009)
             true
             true
             true
             true
             true)
        (and |0_r4_BGP_IMPORT_Ethernet43_permitted|
             (= |0_r4_OVERALL_BEST_None_prefixLength|
                |0_r4_BGP_IMPORT_Ethernet43_prefixLength|)
             true
             (= |0_r4_OVERALL_BEST_None_localPref|
                |0_r4_BGP_IMPORT_Ethernet43_localPref|)
             (= |0_r4_OVERALL_BEST_None_metric|
                |0_r4_BGP_IMPORT_Ethernet43_metric|)
             (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet43_med|)
             true
             true
             (= |0_r4_OVERALL_BEST_None_routerID| 50529027)
             true
             true
             true
             true
             true)
        (and |0_r4_BGP_IMPORT_Ethernet42_permitted|
             (= |0_r4_OVERALL_BEST_None_prefixLength|
                |0_r4_BGP_IMPORT_Ethernet42_prefixLength|)
             true
             (= |0_r4_OVERALL_BEST_None_localPref|
                |0_r4_BGP_IMPORT_Ethernet42_localPref|)
             (= |0_r4_OVERALL_BEST_None_metric|
                |0_r4_BGP_IMPORT_Ethernet42_metric|)
             (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet42_med|)
             true
             true
             (= |0_r4_OVERALL_BEST_None_routerID| 33686018)
             true
             true
             true
             true
             true))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r1_BGP_BEST_None_routerID| 50529027))))))
(let ((a!2 (and (= |0_r1_BGP_BEST_None_med| |0_r3_BGP_EXPORT_Ethernet31_med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r1_BGP_BEST_None_metric|
                  |0_r3_BGP_EXPORT_Ethernet31_metric|)
               (and (= |0_r1_BGP_BEST_None_metric|
                       |0_r3_BGP_EXPORT_Ethernet31_metric|)
                    (or (< |0_r1_BGP_BEST_None_med|
                           |0_r3_BGP_EXPORT_Ethernet31_med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r1_BGP_BEST_None_localPref|
                       |0_r3_BGP_EXPORT_Ethernet31_localPref|)
                    (and (= |0_r1_BGP_BEST_None_localPref|
                            |0_r3_BGP_EXPORT_Ethernet31_localPref|)
                         a!3)))))
  (=> |0_r3_BGP_EXPORT_Ethernet31_permitted|
      (or (> |0_r1_BGP_BEST_None_prefixLength|
             |0_r3_BGP_EXPORT_Ethernet31_prefixLength|)
          (and (= |0_r1_BGP_BEST_None_prefixLength|
                  |0_r3_BGP_EXPORT_Ethernet31_prefixLength|)
               (or false a!4)))))))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r1_BGP_BEST_None_routerID| 67372036))))))
(let ((a!2 (and (= |0_r1_BGP_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r1_BGP_BEST_None_metric| |0_r4_BGP_SINGLE-EXPORT__metric|)
               (and (= |0_r1_BGP_BEST_None_metric|
                       |0_r4_BGP_SINGLE-EXPORT__metric|)
                    (or (< |0_r1_BGP_BEST_None_med|
                           |0_r4_BGP_SINGLE-EXPORT__med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r1_BGP_BEST_None_localPref|
                       |0_r4_BGP_SINGLE-EXPORT__localPref|)
                    (and (= |0_r1_BGP_BEST_None_localPref|
                            |0_r4_BGP_SINGLE-EXPORT__localPref|)
                         a!3)))))
  (=> |0_r4_BGP_SINGLE-EXPORT__permitted|
      (or (> |0_r1_BGP_BEST_None_prefixLength|
             |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
          (and (= |0_r1_BGP_BEST_None_prefixLength|
                  |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
               (or false a!4)))))))))
(assert (let ((a!1 (and true
                (or false
                    (and true (<= |0_r1_BGP_BEST_None_routerID| 33686018))))))
(let ((a!2 (and (= |0_r1_BGP_BEST_None_med| |0_r2_BGP_EXPORT_Ethernet21_med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r1_BGP_BEST_None_metric|
                  |0_r2_BGP_EXPORT_Ethernet21_metric|)
               (and (= |0_r1_BGP_BEST_None_metric|
                       |0_r2_BGP_EXPORT_Ethernet21_metric|)
                    (or (< |0_r1_BGP_BEST_None_med|
                           |0_r2_BGP_EXPORT_Ethernet21_med|)
                        a!2)))))
(let ((a!4 (and true
                (or (> |0_r1_BGP_BEST_None_localPref|
                       |0_r2_BGP_EXPORT_Ethernet21_localPref|)
                    (and (= |0_r1_BGP_BEST_None_localPref|
                            |0_r2_BGP_EXPORT_Ethernet21_localPref|)
                         a!3)))))
  (=> |0_r2_BGP_EXPORT_Ethernet21_permitted|
      (or (> |0_r1_BGP_BEST_None_prefixLength|
             |0_r2_BGP_EXPORT_Ethernet21_prefixLength|)
          (and (= |0_r1_BGP_BEST_None_prefixLength|
                  |0_r2_BGP_EXPORT_Ethernet21_prefixLength|)
               (or false a!4)))))))))
(assert (= (or |0_r3_BGP_EXPORT_Ethernet31_permitted|
       |0_r4_BGP_SINGLE-EXPORT__permitted|
       |0_r2_BGP_EXPORT_Ethernet21_permitted|)
   |0_r1_BGP_BEST_None_permitted|))
(assert (=> (or |0_r3_BGP_EXPORT_Ethernet31_permitted|
        |0_r4_BGP_SINGLE-EXPORT__permitted|
        |0_r2_BGP_EXPORT_Ethernet21_permitted|)
    (or (and |0_r3_BGP_EXPORT_Ethernet31_permitted|
             (= |0_r1_BGP_BEST_None_prefixLength|
                |0_r3_BGP_EXPORT_Ethernet31_prefixLength|)
             true
             (= |0_r1_BGP_BEST_None_localPref|
                |0_r3_BGP_EXPORT_Ethernet31_localPref|)
             (= |0_r1_BGP_BEST_None_metric| |0_r3_BGP_EXPORT_Ethernet31_metric|)
             (= |0_r1_BGP_BEST_None_med| |0_r3_BGP_EXPORT_Ethernet31_med|)
             true
             true
             (= |0_r1_BGP_BEST_None_routerID| 50529027)
             true
             true
             true
             true
             true)
        (and |0_r4_BGP_SINGLE-EXPORT__permitted|
             (= |0_r1_BGP_BEST_None_prefixLength|
                |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
             true
             (= |0_r1_BGP_BEST_None_localPref|
                |0_r4_BGP_SINGLE-EXPORT__localPref|)
             (= |0_r1_BGP_BEST_None_metric| |0_r4_BGP_SINGLE-EXPORT__metric|)
             (= |0_r1_BGP_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
             true
             true
             (= |0_r1_BGP_BEST_None_routerID| 67372036)
             true
             true
             true
             true
             true)
        (and |0_r2_BGP_EXPORT_Ethernet21_permitted|
             (= |0_r1_BGP_BEST_None_prefixLength|
                |0_r2_BGP_EXPORT_Ethernet21_prefixLength|)
             true
             (= |0_r1_BGP_BEST_None_localPref|
                |0_r2_BGP_EXPORT_Ethernet21_localPref|)
             (= |0_r1_BGP_BEST_None_metric| |0_r2_BGP_EXPORT_Ethernet21_metric|)
             (= |0_r1_BGP_BEST_None_med| |0_r2_BGP_EXPORT_Ethernet21_med|)
             true
             true
             (= |0_r1_BGP_BEST_None_routerID| 33686018)
             true
             true
             true
             true
             true))))
(assert (= |0_r2_BGP_IMPORT_Ethernet21_choice|
   (and |0_r2_BGP_IMPORT_Ethernet21_permitted|
        (= |0_r2_OVERALL_BEST_None_prefixLength|
           |0_r2_BGP_IMPORT_Ethernet21_prefixLength|)
        true
        (= |0_r2_OVERALL_BEST_None_localPref|
           |0_r2_BGP_IMPORT_Ethernet21_localPref|)
        (= |0_r2_OVERALL_BEST_None_metric| |0_r2_BGP_IMPORT_Ethernet21_metric|)
        (= |0_r2_OVERALL_BEST_None_med| |0_r2_BGP_IMPORT_Ethernet21_med|)
        true
        true
        (= |0_r2_OVERALL_BEST_None_routerID| 16843009)
        true
        true
        true
        true
        true)))
(assert (= |0_r2_BGP_IMPORT_Ethernet24_choice|
   (and |0_r4_BGP_SINGLE-EXPORT__permitted|
        (= |0_r2_OVERALL_BEST_None_prefixLength|
           |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
        true
        (= |0_r2_OVERALL_BEST_None_localPref|
           |0_r4_BGP_SINGLE-EXPORT__localPref|)
        (= |0_r2_OVERALL_BEST_None_metric| |0_r4_BGP_SINGLE-EXPORT__metric|)
        (= |0_r2_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
        true
        true
        (= |0_r2_OVERALL_BEST_None_routerID| 67372036)
        true
        true
        true
        true
        true)))
(assert (= |0_r3_BGP_IMPORT_Ethernet31_choice|
   (and |0_r3_BGP_IMPORT_Ethernet31_permitted|
        (= |0_r3_OVERALL_BEST_None_prefixLength|
           |0_r3_BGP_IMPORT_Ethernet31_prefixLength|)
        true
        (= |0_r3_OVERALL_BEST_None_localPref|
           |0_r3_BGP_IMPORT_Ethernet31_localPref|)
        (= |0_r3_OVERALL_BEST_None_metric| |0_r3_BGP_IMPORT_Ethernet31_metric|)
        (= |0_r3_OVERALL_BEST_None_med| |0_r3_BGP_IMPORT_Ethernet31_med|)
        true
        true
        (= |0_r3_OVERALL_BEST_None_routerID| 16843009)
        true
        true
        true
        true
        true)))
(assert (= |0_r3_BGP_IMPORT_Ethernet34_choice|
   (and |0_r4_BGP_SINGLE-EXPORT__permitted|
        (= |0_r3_OVERALL_BEST_None_prefixLength|
           |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
        true
        (= |0_r3_OVERALL_BEST_None_localPref|
           |0_r4_BGP_SINGLE-EXPORT__localPref|)
        (= |0_r3_OVERALL_BEST_None_metric| |0_r4_BGP_SINGLE-EXPORT__metric|)
        (= |0_r3_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
        true
        true
        (= |0_r3_OVERALL_BEST_None_routerID| 67372036)
        true
        true
        true
        true
        true)))
(assert (= |0_r4_BGP_IMPORT_Ethernet41_choice|
   (and |0_r4_BGP_IMPORT_Ethernet41_permitted|
        (= |0_r4_OVERALL_BEST_None_prefixLength|
           |0_r4_BGP_IMPORT_Ethernet41_prefixLength|)
        true
        (= |0_r4_OVERALL_BEST_None_localPref|
           |0_r4_BGP_IMPORT_Ethernet41_localPref|)
        (= |0_r4_OVERALL_BEST_None_metric| |0_r4_BGP_IMPORT_Ethernet41_metric|)
        (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet41_med|)
        true
        true
        (= |0_r4_OVERALL_BEST_None_routerID| 16843009)
        true
        true
        true
        true
        true)))
(assert (= |0_r4_BGP_IMPORT_Ethernet43_choice|
   (and |0_r4_BGP_IMPORT_Ethernet43_permitted|
        (= |0_r4_OVERALL_BEST_None_prefixLength|
           |0_r4_BGP_IMPORT_Ethernet43_prefixLength|)
        true
        (= |0_r4_OVERALL_BEST_None_localPref|
           |0_r4_BGP_IMPORT_Ethernet43_localPref|)
        (= |0_r4_OVERALL_BEST_None_metric| |0_r4_BGP_IMPORT_Ethernet43_metric|)
        (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet43_med|)
        true
        true
        (= |0_r4_OVERALL_BEST_None_routerID| 50529027)
        true
        true
        true
        true
        true)))
(assert (= |0_r4_BGP_IMPORT_Ethernet42_choice|
   (and |0_r4_BGP_IMPORT_Ethernet42_permitted|
        (= |0_r4_OVERALL_BEST_None_prefixLength|
           |0_r4_BGP_IMPORT_Ethernet42_prefixLength|)
        true
        (= |0_r4_OVERALL_BEST_None_localPref|
           |0_r4_BGP_IMPORT_Ethernet42_localPref|)
        (= |0_r4_OVERALL_BEST_None_metric| |0_r4_BGP_IMPORT_Ethernet42_metric|)
        (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet42_med|)
        true
        true
        (= |0_r4_OVERALL_BEST_None_routerID| 33686018)
        true
        true
        true
        true
        true)))
(assert (= |0_r1_BGP_IMPORT_Ethernet13_choice|
   (and |0_r3_BGP_EXPORT_Ethernet31_permitted|
        (= |0_r1_BGP_BEST_None_prefixLength|
           |0_r3_BGP_EXPORT_Ethernet31_prefixLength|)
        true
        (= |0_r1_BGP_BEST_None_localPref|
           |0_r3_BGP_EXPORT_Ethernet31_localPref|)
        (= |0_r1_BGP_BEST_None_metric| |0_r3_BGP_EXPORT_Ethernet31_metric|)
        (= |0_r1_BGP_BEST_None_med| |0_r3_BGP_EXPORT_Ethernet31_med|)
        true
        true
        (= |0_r1_BGP_BEST_None_routerID| 50529027)
        true
        true
        true
        true
        true)))
(assert (= |0_r1_BGP_IMPORT_Ethernet14_choice|
   (and |0_r4_BGP_SINGLE-EXPORT__permitted|
        (= |0_r1_BGP_BEST_None_prefixLength|
           |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
        true
        (= |0_r1_BGP_BEST_None_localPref| |0_r4_BGP_SINGLE-EXPORT__localPref|)
        (= |0_r1_BGP_BEST_None_metric| |0_r4_BGP_SINGLE-EXPORT__metric|)
        (= |0_r1_BGP_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
        true
        true
        (= |0_r1_BGP_BEST_None_routerID| 67372036)
        true
        true
        true
        true
        true)))
(assert (= |0_r1_BGP_IMPORT_Ethernet12_choice|
   (and |0_r2_BGP_EXPORT_Ethernet21_permitted|
        (= |0_r1_BGP_BEST_None_prefixLength|
           |0_r2_BGP_EXPORT_Ethernet21_prefixLength|)
        true
        (= |0_r1_BGP_BEST_None_localPref|
           |0_r2_BGP_EXPORT_Ethernet21_localPref|)
        (= |0_r1_BGP_BEST_None_metric| |0_r2_BGP_EXPORT_Ethernet21_metric|)
        (= |0_r1_BGP_BEST_None_med| |0_r2_BGP_EXPORT_Ethernet21_med|)
        true
        true
        (= |0_r1_BGP_BEST_None_routerID| 33686018)
        true
        true
        true
        true
        true)))
(assert (let ((a!1 (and true
                (or false
                    (and true
                         (<= |0_r1_OVERALL_BEST_None_routerID|
                             |0_r1_BGP_BEST_None_routerID|))))))
(let ((a!2 (and (= |0_r1_OVERALL_BEST_None_med| |0_r1_BGP_BEST_None_med|)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r1_OVERALL_BEST_None_metric| |0_r1_BGP_BEST_None_metric|)
               (and (= |0_r1_OVERALL_BEST_None_metric|
                       |0_r1_BGP_BEST_None_metric|)
                    (or (< |0_r1_OVERALL_BEST_None_med|
                           |0_r1_BGP_BEST_None_med|)
                        a!2)))))
(let ((a!4 (and (= |0_r1_OVERALL_BEST_None_adminDist| 20)
                (or (> |0_r1_OVERALL_BEST_None_localPref|
                       |0_r1_BGP_BEST_None_localPref|)
                    (and (= |0_r1_OVERALL_BEST_None_localPref|
                            |0_r1_BGP_BEST_None_localPref|)
                         a!3)))))
(let ((a!5 (or (> |0_r1_OVERALL_BEST_None_prefixLength|
                  |0_r1_BGP_BEST_None_prefixLength|)
               (and (= |0_r1_OVERALL_BEST_None_prefixLength|
                       |0_r1_BGP_BEST_None_prefixLength|)
                    (or (< |0_r1_OVERALL_BEST_None_adminDist| 20) a!4)))))
  (=> |0_r1_BGP_BEST_None_permitted| a!5)))))))
(assert (let ((a!1 (and true
                (or false (and true (<= |0_r1_OVERALL_BEST_None_routerID| 0))))))
(let ((a!2 (and (= |0_r1_OVERALL_BEST_None_med| 0)
                (or false (and true (or false a!1))))))
(let ((a!3 (or (< |0_r1_OVERALL_BEST_None_metric| 0)
               (and (= |0_r1_OVERALL_BEST_None_metric| 0)
                    (or (< |0_r1_OVERALL_BEST_None_med| 0) a!2)))))
(let ((a!4 (and (= |0_r1_OVERALL_BEST_None_adminDist| 0)
                (or (> |0_r1_OVERALL_BEST_None_localPref| 100)
                    (and (= |0_r1_OVERALL_BEST_None_localPref| 100) a!3)))))
(let ((a!5 (or (> |0_r1_OVERALL_BEST_None_prefixLength|
                  |0_r1_CONNECTED_BEST_None_prefixLength|)
               (and (= |0_r1_OVERALL_BEST_None_prefixLength|
                       |0_r1_CONNECTED_BEST_None_prefixLength|)
                    (or (< |0_r1_OVERALL_BEST_None_adminDist| 0) a!4)))))
  (=> |0_r1_CONNECTED_BEST_None_permitted| a!5)))))))
(assert (= (or |0_r1_BGP_BEST_None_permitted| |0_r1_CONNECTED_BEST_None_permitted|)
   |0_r1_OVERALL_BEST_None_permitted|))
(assert (=> (or |0_r1_BGP_BEST_None_permitted| |0_r1_CONNECTED_BEST_None_permitted|)
    (or (and |0_r1_BGP_BEST_None_permitted|
             (= |0_r1_OVERALL_BEST_None_prefixLength|
                |0_r1_BGP_BEST_None_prefixLength|)
             (= |0_r1_OVERALL_BEST_None_adminDist| 20)
             (= |0_r1_OVERALL_BEST_None_localPref|
                |0_r1_BGP_BEST_None_localPref|)
             (= |0_r1_OVERALL_BEST_None_metric| |0_r1_BGP_BEST_None_metric|)
             (= |0_r1_OVERALL_BEST_None_med| |0_r1_BGP_BEST_None_med|)
             true
             true
             (= |0_r1_OVERALL_BEST_None_routerID| |0_r1_BGP_BEST_None_routerID|)
             (= |0_r1_OVERALL_BEST_None_history| #b0)
             true
             true
             true
             true)
        (and |0_r1_CONNECTED_BEST_None_permitted|
             (= |0_r1_OVERALL_BEST_None_prefixLength|
                |0_r1_CONNECTED_BEST_None_prefixLength|)
             (= |0_r1_OVERALL_BEST_None_adminDist| 0)
             (= |0_r1_OVERALL_BEST_None_localPref| 100)
             (= |0_r1_OVERALL_BEST_None_metric| 0)
             (= |0_r1_OVERALL_BEST_None_med| 0)
             true
             true
             true
             (= |0_r1_OVERALL_BEST_None_history| #b1)
             true
             true
             true
             true))))
(assert (=> (and true
         |0_r2_BGP_IMPORT_Ethernet21_choice|
         (= |0_r2_OVERALL_BEST_None_prefixLength|
            |0_r2_BGP_IMPORT_Ethernet21_prefixLength|)
         true
         (= |0_r2_OVERALL_BEST_None_localPref|
            |0_r2_BGP_IMPORT_Ethernet21_localPref|)
         (= |0_r2_OVERALL_BEST_None_metric| |0_r2_BGP_IMPORT_Ethernet21_metric|)
         (= |0_r2_OVERALL_BEST_None_med| |0_r2_BGP_IMPORT_Ethernet21_med|)
         true
         true
         (= |0_r2_OVERALL_BEST_None_routerID| 16843009)
         true
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r2_Ethernet21|))
(assert (=> (and true
         |0_r2_BGP_IMPORT_Ethernet24_choice|
         (= |0_r2_OVERALL_BEST_None_prefixLength|
            |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
         true
         (= |0_r2_OVERALL_BEST_None_localPref|
            |0_r4_BGP_SINGLE-EXPORT__localPref|)
         (= |0_r2_OVERALL_BEST_None_metric| |0_r4_BGP_SINGLE-EXPORT__metric|)
         (= |0_r2_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
         true
         true
         (= |0_r2_OVERALL_BEST_None_routerID| 67372036)
         true
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r2_Ethernet24|))
(assert (=> (not (and true
              |0_r2_BGP_IMPORT_Ethernet21_choice|
              (= |0_r2_OVERALL_BEST_None_prefixLength|
                 |0_r2_BGP_IMPORT_Ethernet21_prefixLength|)
              true
              (= |0_r2_OVERALL_BEST_None_localPref|
                 |0_r2_BGP_IMPORT_Ethernet21_localPref|)
              (= |0_r2_OVERALL_BEST_None_metric|
                 |0_r2_BGP_IMPORT_Ethernet21_metric|)
              (= |0_r2_OVERALL_BEST_None_med| |0_r2_BGP_IMPORT_Ethernet21_med|)
              true
              true
              (= |0_r2_OVERALL_BEST_None_routerID| 16843009)
              true
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r2_Ethernet21|)))
(assert (=> (not (and true
              |0_r2_BGP_IMPORT_Ethernet24_choice|
              (= |0_r2_OVERALL_BEST_None_prefixLength|
                 |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
              true
              (= |0_r2_OVERALL_BEST_None_localPref|
                 |0_r4_BGP_SINGLE-EXPORT__localPref|)
              (= |0_r2_OVERALL_BEST_None_metric|
                 |0_r4_BGP_SINGLE-EXPORT__metric|)
              (= |0_r2_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
              true
              true
              (= |0_r2_OVERALL_BEST_None_routerID| 67372036)
              true
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r2_Ethernet24|)))
(assert (=> (and true
         |0_r3_BGP_IMPORT_Ethernet31_choice|
         (= |0_r3_OVERALL_BEST_None_prefixLength|
            |0_r3_BGP_IMPORT_Ethernet31_prefixLength|)
         true
         (= |0_r3_OVERALL_BEST_None_localPref|
            |0_r3_BGP_IMPORT_Ethernet31_localPref|)
         (= |0_r3_OVERALL_BEST_None_metric| |0_r3_BGP_IMPORT_Ethernet31_metric|)
         (= |0_r3_OVERALL_BEST_None_med| |0_r3_BGP_IMPORT_Ethernet31_med|)
         true
         true
         (= |0_r3_OVERALL_BEST_None_routerID| 16843009)
         true
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r3_Ethernet31|))
(assert (=> (and true
         |0_r3_BGP_IMPORT_Ethernet34_choice|
         (= |0_r3_OVERALL_BEST_None_prefixLength|
            |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
         true
         (= |0_r3_OVERALL_BEST_None_localPref|
            |0_r4_BGP_SINGLE-EXPORT__localPref|)
         (= |0_r3_OVERALL_BEST_None_metric| |0_r4_BGP_SINGLE-EXPORT__metric|)
         (= |0_r3_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
         true
         true
         (= |0_r3_OVERALL_BEST_None_routerID| 67372036)
         true
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r3_Ethernet34|))
(assert (=> (not (and true
              |0_r3_BGP_IMPORT_Ethernet34_choice|
              (= |0_r3_OVERALL_BEST_None_prefixLength|
                 |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
              true
              (= |0_r3_OVERALL_BEST_None_localPref|
                 |0_r4_BGP_SINGLE-EXPORT__localPref|)
              (= |0_r3_OVERALL_BEST_None_metric|
                 |0_r4_BGP_SINGLE-EXPORT__metric|)
              (= |0_r3_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
              true
              true
              (= |0_r3_OVERALL_BEST_None_routerID| 67372036)
              true
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r3_Ethernet34|)))
(assert (=> (not (and true
              |0_r3_BGP_IMPORT_Ethernet31_choice|
              (= |0_r3_OVERALL_BEST_None_prefixLength|
                 |0_r3_BGP_IMPORT_Ethernet31_prefixLength|)
              true
              (= |0_r3_OVERALL_BEST_None_localPref|
                 |0_r3_BGP_IMPORT_Ethernet31_localPref|)
              (= |0_r3_OVERALL_BEST_None_metric|
                 |0_r3_BGP_IMPORT_Ethernet31_metric|)
              (= |0_r3_OVERALL_BEST_None_med| |0_r3_BGP_IMPORT_Ethernet31_med|)
              true
              true
              (= |0_r3_OVERALL_BEST_None_routerID| 16843009)
              true
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r3_Ethernet31|)))
(assert (=> (and true
         |0_r4_BGP_IMPORT_Ethernet41_choice|
         (= |0_r4_OVERALL_BEST_None_prefixLength|
            |0_r4_BGP_IMPORT_Ethernet41_prefixLength|)
         true
         (= |0_r4_OVERALL_BEST_None_localPref|
            |0_r4_BGP_IMPORT_Ethernet41_localPref|)
         (= |0_r4_OVERALL_BEST_None_metric| |0_r4_BGP_IMPORT_Ethernet41_metric|)
         (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet41_med|)
         true
         true
         (= |0_r4_OVERALL_BEST_None_routerID| 16843009)
         true
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r4_Ethernet41|))
(assert (=> (and true
         |0_r4_BGP_IMPORT_Ethernet43_choice|
         (= |0_r4_OVERALL_BEST_None_prefixLength|
            |0_r4_BGP_IMPORT_Ethernet43_prefixLength|)
         true
         (= |0_r4_OVERALL_BEST_None_localPref|
            |0_r4_BGP_IMPORT_Ethernet43_localPref|)
         (= |0_r4_OVERALL_BEST_None_metric| |0_r4_BGP_IMPORT_Ethernet43_metric|)
         (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet43_med|)
         true
         true
         (= |0_r4_OVERALL_BEST_None_routerID| 50529027)
         true
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r4_Ethernet43|))
(assert (=> (and true
         |0_r4_BGP_IMPORT_Ethernet42_choice|
         (= |0_r4_OVERALL_BEST_None_prefixLength|
            |0_r4_BGP_IMPORT_Ethernet42_prefixLength|)
         true
         (= |0_r4_OVERALL_BEST_None_localPref|
            |0_r4_BGP_IMPORT_Ethernet42_localPref|)
         (= |0_r4_OVERALL_BEST_None_metric| |0_r4_BGP_IMPORT_Ethernet42_metric|)
         (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet42_med|)
         true
         true
         (= |0_r4_OVERALL_BEST_None_routerID| 33686018)
         true
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r4_Ethernet42|))
(assert (=> (not (and true
              |0_r4_BGP_IMPORT_Ethernet41_choice|
              (= |0_r4_OVERALL_BEST_None_prefixLength|
                 |0_r4_BGP_IMPORT_Ethernet41_prefixLength|)
              true
              (= |0_r4_OVERALL_BEST_None_localPref|
                 |0_r4_BGP_IMPORT_Ethernet41_localPref|)
              (= |0_r4_OVERALL_BEST_None_metric|
                 |0_r4_BGP_IMPORT_Ethernet41_metric|)
              (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet41_med|)
              true
              true
              (= |0_r4_OVERALL_BEST_None_routerID| 16843009)
              true
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r4_Ethernet41|)))
(assert (=> (not (and true
              |0_r4_BGP_IMPORT_Ethernet43_choice|
              (= |0_r4_OVERALL_BEST_None_prefixLength|
                 |0_r4_BGP_IMPORT_Ethernet43_prefixLength|)
              true
              (= |0_r4_OVERALL_BEST_None_localPref|
                 |0_r4_BGP_IMPORT_Ethernet43_localPref|)
              (= |0_r4_OVERALL_BEST_None_metric|
                 |0_r4_BGP_IMPORT_Ethernet43_metric|)
              (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet43_med|)
              true
              true
              (= |0_r4_OVERALL_BEST_None_routerID| 50529027)
              true
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r4_Ethernet43|)))
(assert (=> (not (and true
              |0_r4_BGP_IMPORT_Ethernet42_choice|
              (= |0_r4_OVERALL_BEST_None_prefixLength|
                 |0_r4_BGP_IMPORT_Ethernet42_prefixLength|)
              true
              (= |0_r4_OVERALL_BEST_None_localPref|
                 |0_r4_BGP_IMPORT_Ethernet42_localPref|)
              (= |0_r4_OVERALL_BEST_None_metric|
                 |0_r4_BGP_IMPORT_Ethernet42_metric|)
              (= |0_r4_OVERALL_BEST_None_med| |0_r4_BGP_IMPORT_Ethernet42_med|)
              true
              true
              (= |0_r4_OVERALL_BEST_None_routerID| 33686018)
              true
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r4_Ethernet42|)))
(assert (=> (and true
         |0_r1_BGP_IMPORT_Ethernet13_choice|
         (= |0_r1_OVERALL_BEST_None_prefixLength|
            |0_r3_BGP_EXPORT_Ethernet31_prefixLength|)
         (= |0_r1_OVERALL_BEST_None_adminDist| 20)
         (= |0_r1_OVERALL_BEST_None_localPref|
            |0_r3_BGP_EXPORT_Ethernet31_localPref|)
         (= |0_r1_OVERALL_BEST_None_metric| |0_r3_BGP_EXPORT_Ethernet31_metric|)
         (= |0_r1_OVERALL_BEST_None_med| |0_r3_BGP_EXPORT_Ethernet31_med|)
         true
         true
         (= |0_r1_OVERALL_BEST_None_routerID| 50529027)
         (= |0_r1_OVERALL_BEST_None_history| #b0)
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r1_Ethernet13|))
(assert (=> (and true
         |0_r1_BGP_IMPORT_Ethernet14_choice|
         (= |0_r1_OVERALL_BEST_None_prefixLength|
            |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
         (= |0_r1_OVERALL_BEST_None_adminDist| 20)
         (= |0_r1_OVERALL_BEST_None_localPref|
            |0_r4_BGP_SINGLE-EXPORT__localPref|)
         (= |0_r1_OVERALL_BEST_None_metric| |0_r4_BGP_SINGLE-EXPORT__metric|)
         (= |0_r1_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
         true
         true
         (= |0_r1_OVERALL_BEST_None_routerID| 67372036)
         (= |0_r1_OVERALL_BEST_None_history| #b0)
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r1_Ethernet14|))
(assert (=> (and true
         |0_r1_BGP_IMPORT_Ethernet12_choice|
         (= |0_r1_OVERALL_BEST_None_prefixLength|
            |0_r2_BGP_EXPORT_Ethernet21_prefixLength|)
         (= |0_r1_OVERALL_BEST_None_adminDist| 20)
         (= |0_r1_OVERALL_BEST_None_localPref|
            |0_r2_BGP_EXPORT_Ethernet21_localPref|)
         (= |0_r1_OVERALL_BEST_None_metric| |0_r2_BGP_EXPORT_Ethernet21_metric|)
         (= |0_r1_OVERALL_BEST_None_med| |0_r2_BGP_EXPORT_Ethernet21_med|)
         true
         true
         (= |0_r1_OVERALL_BEST_None_routerID| 33686018)
         (= |0_r1_OVERALL_BEST_None_history| #b0)
         true
         true
         true
         true)
    |0_CONTROL-FORWARDING_r1_Ethernet12|))
(assert (not |0_CONTROL-FORWARDING_r1_Loopback0|))
(assert (=> (not (and true
              |0_r1_BGP_IMPORT_Ethernet12_choice|
              (= |0_r1_OVERALL_BEST_None_prefixLength|
                 |0_r2_BGP_EXPORT_Ethernet21_prefixLength|)
              (= |0_r1_OVERALL_BEST_None_adminDist| 20)
              (= |0_r1_OVERALL_BEST_None_localPref|
                 |0_r2_BGP_EXPORT_Ethernet21_localPref|)
              (= |0_r1_OVERALL_BEST_None_metric|
                 |0_r2_BGP_EXPORT_Ethernet21_metric|)
              (= |0_r1_OVERALL_BEST_None_med| |0_r2_BGP_EXPORT_Ethernet21_med|)
              true
              true
              (= |0_r1_OVERALL_BEST_None_routerID| 33686018)
              (= |0_r1_OVERALL_BEST_None_history| #b0)
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r1_Ethernet12|)))
(assert (=> (not (and true
              |0_r1_BGP_IMPORT_Ethernet13_choice|
              (= |0_r1_OVERALL_BEST_None_prefixLength|
                 |0_r3_BGP_EXPORT_Ethernet31_prefixLength|)
              (= |0_r1_OVERALL_BEST_None_adminDist| 20)
              (= |0_r1_OVERALL_BEST_None_localPref|
                 |0_r3_BGP_EXPORT_Ethernet31_localPref|)
              (= |0_r1_OVERALL_BEST_None_metric|
                 |0_r3_BGP_EXPORT_Ethernet31_metric|)
              (= |0_r1_OVERALL_BEST_None_med| |0_r3_BGP_EXPORT_Ethernet31_med|)
              true
              true
              (= |0_r1_OVERALL_BEST_None_routerID| 50529027)
              (= |0_r1_OVERALL_BEST_None_history| #b0)
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r1_Ethernet13|)))
(assert (=> (not (and true
              |0_r1_BGP_IMPORT_Ethernet14_choice|
              (= |0_r1_OVERALL_BEST_None_prefixLength|
                 |0_r4_BGP_SINGLE-EXPORT__prefixLength|)
              (= |0_r1_OVERALL_BEST_None_adminDist| 20)
              (= |0_r1_OVERALL_BEST_None_localPref|
                 |0_r4_BGP_SINGLE-EXPORT__localPref|)
              (= |0_r1_OVERALL_BEST_None_metric|
                 |0_r4_BGP_SINGLE-EXPORT__metric|)
              (= |0_r1_OVERALL_BEST_None_med| |0_r4_BGP_SINGLE-EXPORT__med|)
              true
              true
              (= |0_r1_OVERALL_BEST_None_routerID| 67372036)
              (= |0_r1_OVERALL_BEST_None_history| #b0)
              true
              true
              true
              true))
    (not |0_CONTROL-FORWARDING_r1_Ethernet14|)))
(assert (not |0_CONTROL-FORWARDING_r1_Loopback0|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r2_Ethernet21|) true)
   |0_DATA-FORWARDING_r2_Ethernet21|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r2_Ethernet24|) true)
   |0_DATA-FORWARDING_r2_Ethernet24|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r3_Ethernet34|) true)
   |0_DATA-FORWARDING_r3_Ethernet34|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r3_Ethernet31|) true)
   |0_DATA-FORWARDING_r3_Ethernet31|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r4_Ethernet41|) true)
   |0_DATA-FORWARDING_r4_Ethernet41|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r4_Ethernet43|) true)
   |0_DATA-FORWARDING_r4_Ethernet43|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r4_Ethernet42|) true)
   |0_DATA-FORWARDING_r4_Ethernet42|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r1_Loopback0|) true)
   |0_DATA-FORWARDING_r1_Loopback0|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r1_Ethernet12|) true)
   |0_DATA-FORWARDING_r1_Ethernet12|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r1_Ethernet13|) true)
   |0_DATA-FORWARDING_r1_Ethernet13|))
(assert (= (and (or false |0_CONTROL-FORWARDING_r1_Ethernet14|) true)
   |0_DATA-FORWARDING_r1_Ethernet14|))
(assert (=> (not |0_r2_OVERALL_BEST_None_permitted|) (= |0_r2_OVERALL_BEST_None_med| 0)))
(assert (=> (not |0_r2_OVERALL_BEST_None_permitted|)
    (= |0_r2_OVERALL_BEST_None_localPref| 0)))
(assert (=> (not |0_r2_OVERALL_BEST_None_permitted|)
    (= |0_r2_OVERALL_BEST_None_prefixLength| 0)))
(assert (=> (not |0_r2_OVERALL_BEST_None_permitted|)
    (= |0_r2_OVERALL_BEST_None_metric| 0)))
(assert (=> (not |0_r2_OVERALL_BEST_None_permitted|) true))
(assert (=> (not |0_r2_OVERALL_BEST_None_permitted|)
    (= |0_r2_OVERALL_BEST_None_routerID| 0)))
(assert (=> (not |0_r3_OVERALL_BEST_None_permitted|) (= |0_r3_OVERALL_BEST_None_med| 0)))
(assert (=> (not |0_r3_OVERALL_BEST_None_permitted|)
    (= |0_r3_OVERALL_BEST_None_localPref| 0)))
(assert (=> (not |0_r3_OVERALL_BEST_None_permitted|)
    (= |0_r3_OVERALL_BEST_None_prefixLength| 0)))
(assert (=> (not |0_r3_OVERALL_BEST_None_permitted|)
    (= |0_r3_OVERALL_BEST_None_metric| 0)))
(assert (=> (not |0_r3_OVERALL_BEST_None_permitted|) true))
(assert (=> (not |0_r3_OVERALL_BEST_None_permitted|)
    (= |0_r3_OVERALL_BEST_None_routerID| 0)))
(assert (=> (not |0_r4_OVERALL_BEST_None_permitted|) (= |0_r4_OVERALL_BEST_None_med| 0)))
(assert (=> (not |0_r4_OVERALL_BEST_None_permitted|)
    (= |0_r4_OVERALL_BEST_None_localPref| 0)))
(assert (=> (not |0_r4_OVERALL_BEST_None_permitted|)
    (= |0_r4_OVERALL_BEST_None_prefixLength| 0)))
(assert (=> (not |0_r4_OVERALL_BEST_None_permitted|)
    (= |0_r4_OVERALL_BEST_None_metric| 0)))
(assert (=> (not |0_r4_OVERALL_BEST_None_permitted|) true))
(assert (=> (not |0_r4_OVERALL_BEST_None_permitted|)
    (= |0_r4_OVERALL_BEST_None_routerID| 0)))
(assert (=> (not |0_r1_OVERALL_BEST_None_permitted|)
    (= |0_r1_OVERALL_BEST_None_adminDist| 0)))
(assert (=> (not |0_r1_OVERALL_BEST_None_permitted|) (= |0_r1_OVERALL_BEST_None_med| 0)))
(assert (=> (not |0_r1_OVERALL_BEST_None_permitted|)
    (= |0_r1_OVERALL_BEST_None_localPref| 0)))
(assert (=> (not |0_r1_OVERALL_BEST_None_permitted|)
    (= |0_r1_OVERALL_BEST_None_prefixLength| 0)))
(assert (=> (not |0_r1_OVERALL_BEST_None_permitted|)
    (= |0_r1_OVERALL_BEST_None_metric| 0)))
(assert (=> (not |0_r1_OVERALL_BEST_None_permitted|)
    (= |0_r1_OVERALL_BEST_None_history| #b0)))
(assert (=> (not |0_r1_OVERALL_BEST_None_permitted|)
    (= |0_r1_OVERALL_BEST_None_routerID| 0)))
(assert (=> (not |0_r1_BGP_BEST_None_permitted|) (= |0_r1_BGP_BEST_None_med| 0)))
(assert (=> (not |0_r1_BGP_BEST_None_permitted|) (= |0_r1_BGP_BEST_None_localPref| 0)))
(assert (=> (not |0_r1_BGP_BEST_None_permitted|)
    (= |0_r1_BGP_BEST_None_prefixLength| 0)))
(assert (=> (not |0_r1_BGP_BEST_None_permitted|) (= |0_r1_BGP_BEST_None_metric| 0)))
(assert (=> (not |0_r1_BGP_BEST_None_permitted|) (= |0_r1_BGP_BEST_None_routerID| 0)))
(assert (=> (not |0_r1_CONNECTED_BEST_None_permitted|)
    (= |0_r1_CONNECTED_BEST_None_prefixLength| 0)))
(assert (=> (not |0_r2_BGP_EXPORT_Ethernet21_permitted|)
    (= |0_r2_BGP_EXPORT_Ethernet21_med| 0)))
(assert (=> (not |0_r2_BGP_EXPORT_Ethernet21_permitted|)
    (= |0_r2_BGP_EXPORT_Ethernet21_localPref| 0)))
(assert (=> (not |0_r2_BGP_EXPORT_Ethernet21_permitted|)
    (= |0_r2_BGP_EXPORT_Ethernet21_prefixLength| 0)))
(assert (=> (not |0_r2_BGP_EXPORT_Ethernet21_permitted|)
    (= |0_r2_BGP_EXPORT_Ethernet21_metric| 0)))
(assert (=> (not |0_r2_BGP_IMPORT_Ethernet21_permitted|)
    (= |0_r2_BGP_IMPORT_Ethernet21_med| 0)))
(assert (=> (not |0_r2_BGP_IMPORT_Ethernet21_permitted|)
    (= |0_r2_BGP_IMPORT_Ethernet21_localPref| 0)))
(assert (=> (not |0_r2_BGP_IMPORT_Ethernet21_permitted|)
    (= |0_r2_BGP_IMPORT_Ethernet21_prefixLength| 0)))
(assert (=> (not |0_r2_BGP_IMPORT_Ethernet21_permitted|)
    (= |0_r2_BGP_IMPORT_Ethernet21_metric| 0)))
(assert (=> (not |0_r2_BGP_EXPORT_Ethernet24_permitted|)
    (= |0_r2_BGP_EXPORT_Ethernet24_med| 0)))
(assert (=> (not |0_r2_BGP_EXPORT_Ethernet24_permitted|)
    (= |0_r2_BGP_EXPORT_Ethernet24_localPref| 0)))
(assert (=> (not |0_r2_BGP_EXPORT_Ethernet24_permitted|)
    (= |0_r2_BGP_EXPORT_Ethernet24_prefixLength| 0)))
(assert (=> (not |0_r2_BGP_EXPORT_Ethernet24_permitted|)
    (= |0_r2_BGP_EXPORT_Ethernet24_metric| 0)))
(assert (=> (not |0_r3_BGP_EXPORT_Ethernet34_permitted|)
    (= |0_r3_BGP_EXPORT_Ethernet34_med| 0)))
(assert (=> (not |0_r3_BGP_EXPORT_Ethernet34_permitted|)
    (= |0_r3_BGP_EXPORT_Ethernet34_localPref| 0)))
(assert (=> (not |0_r3_BGP_EXPORT_Ethernet34_permitted|)
    (= |0_r3_BGP_EXPORT_Ethernet34_prefixLength| 0)))
(assert (=> (not |0_r3_BGP_EXPORT_Ethernet34_permitted|)
    (= |0_r3_BGP_EXPORT_Ethernet34_metric| 0)))
(assert (=> (not |0_r3_BGP_EXPORT_Ethernet31_permitted|)
    (= |0_r3_BGP_EXPORT_Ethernet31_med| 0)))
(assert (=> (not |0_r3_BGP_EXPORT_Ethernet31_permitted|)
    (= |0_r3_BGP_EXPORT_Ethernet31_localPref| 0)))
(assert (=> (not |0_r3_BGP_EXPORT_Ethernet31_permitted|)
    (= |0_r3_BGP_EXPORT_Ethernet31_prefixLength| 0)))
(assert (=> (not |0_r3_BGP_EXPORT_Ethernet31_permitted|)
    (= |0_r3_BGP_EXPORT_Ethernet31_metric| 0)))
(assert (=> (not |0_r3_BGP_IMPORT_Ethernet31_permitted|)
    (= |0_r3_BGP_IMPORT_Ethernet31_med| 0)))
(assert (=> (not |0_r3_BGP_IMPORT_Ethernet31_permitted|)
    (= |0_r3_BGP_IMPORT_Ethernet31_localPref| 0)))
(assert (=> (not |0_r3_BGP_IMPORT_Ethernet31_permitted|)
    (= |0_r3_BGP_IMPORT_Ethernet31_prefixLength| 0)))
(assert (=> (not |0_r3_BGP_IMPORT_Ethernet31_permitted|)
    (= |0_r3_BGP_IMPORT_Ethernet31_metric| 0)))
(assert (=> (not |0_r4_BGP_SINGLE-EXPORT__permitted|)
    (= |0_r4_BGP_SINGLE-EXPORT__med| 0)))
(assert (=> (not |0_r4_BGP_SINGLE-EXPORT__permitted|)
    (= |0_r4_BGP_SINGLE-EXPORT__localPref| 0)))
(assert (=> (not |0_r4_BGP_SINGLE-EXPORT__permitted|)
    (= |0_r4_BGP_SINGLE-EXPORT__prefixLength| 0)))
(assert (=> (not |0_r4_BGP_SINGLE-EXPORT__permitted|)
    (= |0_r4_BGP_SINGLE-EXPORT__metric| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet41_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet41_med| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet41_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet41_localPref| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet41_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet41_prefixLength| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet41_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet41_metric| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet43_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet43_med| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet43_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet43_localPref| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet43_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet43_prefixLength| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet43_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet43_metric| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet42_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet42_med| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet42_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet42_localPref| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet42_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet42_prefixLength| 0)))
(assert (=> (not |0_r4_BGP_IMPORT_Ethernet42_permitted|)
    (= |0_r4_BGP_IMPORT_Ethernet42_metric| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet12_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet12_med| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet12_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet12_localPref| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet12_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet12_prefixLength| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet12_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet12_metric| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet13_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet13_med| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet13_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet13_localPref| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet13_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet13_prefixLength| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet13_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet13_metric| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet14_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet14_med| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet14_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet14_localPref| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet14_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet14_prefixLength| 0)))
(assert (=> (not |0_r1_BGP_EXPORT_Ethernet14_permitted|)
    (= |0_r1_BGP_EXPORT_Ethernet14_metric| 0)))
(assert (=> (not |0_r1_CONNECTED_IMPORT_Loopback0_permitted|)
    (= |0_r1_CONNECTED_IMPORT_Loopback0_prefixLength| 0)))
(assert (and (or (= (bvand |0_dst-ip| #xffffff00) (bvand #x0a000000 #xffffff00)))
     (not or)))
(assert (= |0__reachable_r2| (> |0__reachable-id_r2| 0)))
(assert (>= |0__reachable-id_r2| 0))
(assert (= |0__reachable_r3| (> |0__reachable-id_r3| 0)))
(assert (>= |0__reachable-id_r3| 0))
(assert (= |0__reachable_r4| (> |0__reachable-id_r4| 0)))
(assert (>= |0__reachable-id_r4| 0))
(assert (= |0__reachable_r1| (> |0__reachable-id_r1| 0)))
(assert (>= |0__reachable-id_r1| 0))
(assert (let ((a!1 (and true
                (=> (and |0_DATA-FORWARDING_r2_Ethernet21|
                         true
                         (> |0__reachable-id_r1| 0))
                    (> |0__reachable-id_r2| |0__reachable-id_r1|))
                (=> (and |0_DATA-FORWARDING_r2_Ethernet24|
                         true
                         (> |0__reachable-id_r4| 0))
                    (> |0__reachable-id_r2| |0__reachable-id_r4|)))))
(let ((a!2 (ite (or false
                    (and |0_DATA-FORWARDING_r2_Ethernet21|
                         true
                         (> |0__reachable-id_r1| 0))
                    (and |0_DATA-FORWARDING_r2_Ethernet24|
                         true
                         (> |0__reachable-id_r4| 0)))
                a!1
                (= |0__reachable-id_r2| 0))))
  (ite (or false false) (= |0__reachable-id_r2| 1) a!2))))
(assert (let ((a!1 (and true
                (=> (and |0_DATA-FORWARDING_r3_Ethernet34|
                         true
                         (> |0__reachable-id_r4| 0))
                    (> |0__reachable-id_r3| |0__reachable-id_r4|))
                (=> (and |0_DATA-FORWARDING_r3_Ethernet31|
                         true
                         (> |0__reachable-id_r1| 0))
                    (> |0__reachable-id_r3| |0__reachable-id_r1|)))))
(let ((a!2 (ite (or false
                    (and |0_DATA-FORWARDING_r3_Ethernet34|
                         true
                         (> |0__reachable-id_r4| 0))
                    (and |0_DATA-FORWARDING_r3_Ethernet31|
                         true
                         (> |0__reachable-id_r1| 0)))
                a!1
                (= |0__reachable-id_r3| 0))))
  (ite (or false false) (= |0__reachable-id_r3| 1) a!2))))
(assert (let ((a!1 (and true
                (=> (and |0_DATA-FORWARDING_r4_Ethernet41|
                         true
                         (> |0__reachable-id_r1| 0))
                    (> |0__reachable-id_r4| |0__reachable-id_r1|))
                (=> (and |0_DATA-FORWARDING_r4_Ethernet43|
                         true
                         (> |0__reachable-id_r3| 0))
                    (> |0__reachable-id_r4| |0__reachable-id_r3|))
                (=> (and |0_DATA-FORWARDING_r4_Ethernet42|
                         true
                         (> |0__reachable-id_r2| 0))
                    (> |0__reachable-id_r4| |0__reachable-id_r2|)))))
(let ((a!2 (ite (or false
                    (and |0_DATA-FORWARDING_r4_Ethernet41|
                         true
                         (> |0__reachable-id_r1| 0))
                    (and |0_DATA-FORWARDING_r4_Ethernet43|
                         true
                         (> |0__reachable-id_r3| 0))
                    (and |0_DATA-FORWARDING_r4_Ethernet42|
                         true
                         (> |0__reachable-id_r2| 0)))
                a!1
                (= |0__reachable-id_r4| 0))))
  (ite (or false false) (= |0__reachable-id_r4| 1) a!2))))
(assert (let ((a!1 (and true
                (=> (and |0_DATA-FORWARDING_r1_Ethernet12|
                         true
                         (> |0__reachable-id_r2| 0))
                    (> |0__reachable-id_r1| |0__reachable-id_r2|))
                (=> (and |0_DATA-FORWARDING_r1_Ethernet13|
                         true
                         (> |0__reachable-id_r3| 0))
                    (> |0__reachable-id_r1| |0__reachable-id_r3|))
                (=> (and |0_DATA-FORWARDING_r1_Ethernet14|
                         true
                         (> |0__reachable-id_r4| 0))
                    (> |0__reachable-id_r1| |0__reachable-id_r4|)))))
(let ((a!2 (ite (or false
                    (and |0_DATA-FORWARDING_r1_Ethernet12|
                         true
                         (> |0__reachable-id_r2| 0))
                    (and |0_DATA-FORWARDING_r1_Ethernet13|
                         true
                         (> |0__reachable-id_r3| 0))
                    (and |0_DATA-FORWARDING_r1_Ethernet14|
                         true
                         (> |0__reachable-id_r4| 0)))
                a!1
                (= |0__reachable-id_r1| 0))))
  (ite (or false
           (and |0_DATA-FORWARDING_r1_Loopback0| true)
           false
           (and |0_r1_CONNECTED_BEST_None_permitted| (= |0_dst-ip| #x0a000001))
           (and |0_r1_CONNECTED_BEST_None_permitted| (= |0_dst-ip| #xc0000c01))
           (and |0_r1_CONNECTED_BEST_None_permitted| (= |0_dst-ip| #xc0000d01))
           (and |0_r1_CONNECTED_BEST_None_permitted| (= |0_dst-ip| #xc0000e01)))
       (= |0__reachable-id_r1| 1)
       a!2))))
(assert (not (and true |0__reachable_r4|)))
(assert (= |0_FAILED-EDGE_r1_Loopback0| 0))
(assert (=> (= (bvand |0_dst-ip| #xfffffffc) (bvand #xc0000c00 #xfffffffc))
    (= |0_FAILED-EDGE_r1_r2| 0)))
(assert (=> (= (bvand |0_dst-ip| #xfffffffc) (bvand #xc0000d00 #xfffffffc))
    (= |0_FAILED-EDGE_r1_r3| 0)))
(assert (=> (= (bvand |0_dst-ip| #xfffffffc) (bvand #xc0000e00 #xfffffffc))
    (= |0_FAILED-EDGE_r1_r4| 0)))

(check-sat)
;(get-model)
