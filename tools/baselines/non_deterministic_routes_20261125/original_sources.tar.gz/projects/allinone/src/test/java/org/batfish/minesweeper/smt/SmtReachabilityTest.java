package org.batfish.minesweeper.smt;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import static org.batfish.common.topology.TopologyUtil.synthesizeL3Topology;
import static org.batfish.minesweeper.smt.Encoder.OUTPUT_DIRECTORY_PROPERTY;
import static org.batfish.minesweeper.smt.Encoder.createOutputDirectory;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.ImmutableSet;
import com.google.devtools.build.runfiles.Runfiles;
import com.microsoft.z3.Context;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.SortedMap;
import org.batfish.common.Answerer;
import org.batfish.common.util.BatfishObjectMapper;
// import org.batfish.common.NetworkSnapshot;
import org.batfish.datamodel.DataPlane;
import org.batfish.datamodel.IpWildcard;
import org.batfish.datamodel.Prefix;
import org.batfish.datamodel.answers.AnswerElement;
import org.batfish.datamodel.isis.IsisTopology;
import org.batfish.dataplane.ibdp.FailureDataplaneEnumerator;
import org.batfish.main.Batfish;
import org.batfish.main.BatfishTestUtils;
import org.batfish.main.TestrigText;
import org.batfish.minesweeper.answers.SmtReachabilityAnswerElement;
import org.batfish.minesweeper.question.SmtReachabilityQuestionPlugin.ReachabilityQuestion;
import org.batfish.minesweeper.symbolicroute.BatfishParsedSnapshotPipelineInputBuilder;
import org.batfish.minesweeper.symbolicroute.BatfishSymbolicRoutePipeline;
import org.batfish.minesweeper.symbolicroute.BatfishSymbolicRoutePipelineInput;
import org.batfish.minesweeper.symbolicroute.BatfishSymbolicRoutePipelineResult;
import org.batfish.minesweeper.symbolicroute.Z3RouteGuard;
import org.batfish.minesweeper.symbolicroute.Z3RouteGuardFactory;
import org.batfish.minesweeper.symbolictraffic.execution.SymbolicTrafficPipeline;
import org.batfish.minesweeper.symbolictraffic.execution.TrafficSmtEncoder;
import org.batfish.minesweeper.symbolictraffic.parse.TrafficGraph;
import org.batfish.minesweeper.utils.ConfigLoader;
import org.batfish.minesweeper.utils.RibPrinter;
import org.batfish.question.routes.RoutesAnswerer;
import org.batfish.question.routes.RoutesQuestion;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class SmtReachabilityTest {
  private static final boolean SYMBOLIC =
      Boolean.parseBoolean(System.getenv().getOrDefault("SMT_SYMBOLIC", "true"));
  private static final int K = 1;

  @Rule public TemporaryFolder _temp = new TemporaryFolder();

  private Batfish _batfish;
  // private NetworkSnapshot _snapshot;

  // printers for output files
  private PrintWriter _bgpRouteWriter;
  private PrintWriter _dataPlaneWriter;
  private String _outputDir;
  private long _configurationInputStarted;

  @Before
  public void setup() throws IOException {
    System.out.println();
    // Beijing timezone
    ZoneId chinaZone = ZoneId.of("Asia/Shanghai");
    // Current time in Beijing
    LocalDateTime beijingTime = LocalDateTime.now(chinaZone);
    // Format output
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    String formattedNow = beijingTime.format(formatter);
    // Output the beijing time for the beginning of the test running
    System.out.println("=== Running test at " + formattedNow + " (Beijing Time) ===");

    _outputDir =
        SYMBOLIC ? createNumberedOutputDirectory("symbolic_output_") : createOutputDirectory();
    if (SYMBOLIC) {
      System.setProperty(OUTPUT_DIRECTORY_PROPERTY, _outputDir);
    } else {
      System.clearProperty(OUTPUT_DIRECTORY_PROPERTY);
    }
    System.out.println(
        (SYMBOLIC ? "SYMBOLIC_OUTPUT_DIRECTORY=" : "SMT_OUTPUT_DIRECTORY=") + _outputDir);
    String outputBgpRouteFileName = _outputDir + "/0_ebgp_routes.txt";
    String outputDataPlaneFileName = _outputDir + "/0_data_plane.txt";
    if (!SYMBOLIC
        && !Boolean.parseBoolean(System.getenv().getOrDefault("SMT_ENUMERATE_FAILURES", "false"))) {
      File outputBgpRouteFile = new File(outputBgpRouteFileName);
      File outputDataPlaneFile = new File(outputDataPlaneFileName);
      try {
        _bgpRouteWriter = new PrintWriter(new FileWriter(outputBgpRouteFile, true));
        _dataPlaneWriter = new PrintWriter(new FileWriter(outputDataPlaneFile, true));
      } catch (IOException e) {
        System.err.println("Error: Unable to create file: " + e.getMessage());
      }
    }

    // read the configurations from the filesystem
    Runfiles runfiles = Runfiles.create();
    String defaultNetwork =
        SYMBOLIC ? "tolerance-symbolic-route" : "tolerance-symbolic-route_1_r3_r4";
    String network = System.getenv().getOrDefault("SMT_NETWORK", defaultNetwork);
    String configPath = System.getenv("SMT_CONFIG_DIRECTORY");
    if (configPath == null) {
      configPath = runfiles.rlocation("batfish/networks/" + network);
    }
    // : "batfish/networks/tolerance_sr_te_demo_1_d_x");
    // String configPath = runfiles.rlocation("batfish/networks/tolerance-symbolic-route");
    // String configPath =
    // runfiles.rlocation("batfish/networks/userstudy_networks/userstudy_network");
    // String configPath =
    // runfiles.rlocation("batfish/networks/userstudy_networks/userstudy_network_hard");
    // String configPath =
    // runfiles.rlocation("batfish/networks/userstudy_networks/userstudy_network_accessment");
    // String configPath =
    // runfiles.rlocation("batfish/networks/userstudy_networks/userstudy_network_accessment_intro");
    // String configPath =
    // runfiles.rlocation("batfish/networks/userstudy_networks/userstudy_network_coursera");

    // -------------------------------------------------------------

    // String configPath = runfiles.rlocation("batfish/benchmarks/FatTrees/fattree4pol");
    // String configPath = runfiles.rlocation("batfish/benchmarks/FatTrees/fattree8pol");
    // String configPath = runfiles.rlocation("batfish/benchmarks/FatTrees/fattree12pol");
    // String configPath = runfiles.rlocation("batfish/benchmarks/FatTrees/fattree16pol");
    // String configPath = runfiles.rlocation("batfish/benchmarks/FatTrees/fattree20pol");
    // String configPath = runfiles.rlocation("batfish/benchmarks/FatTrees/fattree24pol");
    // String configPath = runfiles.rlocation("batfish/benchmarks/FatTrees/fattree28pol");
    // String configPath = runfiles.rlocation("batfish/benchmarks/FatTrees/fattree32pol");

    // -------------------------------------------------------------

    // String configPath = runfiles.rlocation("batfish/benchmarks/Lines/line10");
    // String configPath = runfiles.rlocation("batfish/benchmarks/Lines/line100");
    // String configPath = runfiles.rlocation("batfish/benchmarks/Lines/line1000");
    // String configPath = runfiles.rlocation("batfish/benchmarks/Lines/line2000");
    // String configPath = runfiles.rlocation("batfish/benchmarks/Lines/line5000");
    // String configPath = runfiles.rlocation("batfish/benchmarks/Lines/line10000");

    // -------------------------------------------------------------

    // String configPath = runfiles.rlocation("batfish/benchmarks/Bics/bgp");
    // String configPath = runfiles.rlocation("batfish/benchmarks/Columbus/bgp");
    // String configPath = runfiles.rlocation("batfish/benchmarks/USCarrier/bgp");
    // String configPath = runfiles.rlocation("batfish/benchmarks/Internet2/");

    // -------------------------------------------------------------

    if (Boolean.parseBoolean(System.getenv("SMT_PROFILE_GENERATION"))) {
      System.setProperty("batfish.guard.profile", "true");
      System.setProperty(
          "batfish.guard.forceSolver",
          Boolean.toString(Boolean.parseBoolean(System.getenv("SMT_GUARD_FORCE_SOLVER"))));
    }
    _configurationInputStarted = System.nanoTime();
    TestrigText _testrig = loadConfigurations(configPath);
    _batfish = BatfishTestUtils.getBatfishFromTestrigText(_testrig, _temp);

    if (Boolean.parseBoolean(System.getenv().getOrDefault("SMT_ENUMERATE_FAILURES", "false"))) {
      return;
    }
    long phase = recordGenerationPhase("configuration_load", _configurationInputStarted);
    long start = System.currentTimeMillis();
    // compute data plane for printing RIBs before
    if (SYMBOLIC) {
      _batfish.computeDataPlane(_batfish.getSnapshot());
    } else {
      _batfish.computeDataPlane(_batfish.getSnapshot(), _bgpRouteWriter);
    }
    DataPlane dataPlane = _batfish.loadDataPlane(_batfish.getSnapshot());
    phase = recordGenerationPhase("no_failure_dataplane", phase);
    // print MAIN RIB (forwarding table) of the data plane: one best route per prefix per node.
    RoutesQuestion routesQuestion = new RoutesQuestion();
    RoutesAnswerer routesAnswerer = new RoutesAnswerer(routesQuestion, _batfish);
    AnswerElement routesAnswer = routesAnswerer.answer(_batfish.getSnapshot());
    if (SYMBOLIC) {
      recordGenerationPhase("concrete_rib_export", phase);
      writeToleranceSymbolicRoutes(dataPlane);
    } else {
      RibPrinter.printRouteTable(
          routesAnswer, _dataPlaneWriter, SmtReachabilityTest::selectedOutputProtocol);
      recordGenerationPhase("concrete_rib_export", phase);
      if (!Boolean.parseBoolean(System.getenv("SMT_SKIP_SYMBOLIC_ROUTES"))) {
        writeSnapshotSymbolicRoutes(dataPlane, configPath);
      }
    }
    long end = System.currentTimeMillis();
    System.out.println(
        "[Time taken to compute data plane and print RIBs: " + (end - start) + " ms]");
  }

  /** Optional concrete traversal export. Separate from the symbolic production pipeline. */
  @Test
  public void testFailureDataplaneEnumeration() throws IOException {
    if (!Boolean.parseBoolean(System.getenv().getOrDefault("SMT_ENUMERATE_FAILURES", "false"))) {
      return;
    }
    SortedMap<String, org.batfish.datamodel.Configuration> configurations =
        _batfish.loadConfigurations(_batfish.getSnapshot());
    Set<SmtProtocolSelection.Family> protocols = SmtProtocolSelection.fromRuntime();
    configurations
        .values()
        .forEach(
            c ->
                c.getVrfs()
                    .values()
                    .forEach(
                        v -> {
                          if (!protocols.contains(SmtProtocolSelection.Family.ISIS)) {
                            v.setIsisProcess(null);
                          }
                          if (!protocols.contains(SmtProtocolSelection.Family.OSPF)) {
                            v.setOspfProcesses(new java.util.TreeMap<>());
                          }
                          if (!protocols.contains(SmtProtocolSelection.Family.BGP)) {
                            v.setBgpProcess(null);
                          }
                        }));
    int k = Integer.parseInt(System.getenv().getOrDefault("FAIL_K", "2"));
    FailureDataplaneEnumerator.FailureMode mode =
        FailureDataplaneEnumerator.FailureMode.valueOf(
            System.getenv().getOrDefault("FAIL_MODE", "AT_MOST_K"));
    long started = System.nanoTime();
    int count =
        FailureDataplaneEnumerator.enumerateAndDumpMainRibs(
                configurations, k, mode, Set.of(), Paths.get(_outputDir, "failure_enumeration"))
            .size();
    Files.writeString(
        Paths.get(_outputDir, "failure_export_summary.txt"),
        "Protocols: "
            + protocols
            + "\nMode: "
            + mode
            + "\nK: "
            + k
            + "\nScenarios: "
            + count
            + "\nExport wall seconds: "
            + (System.nanoTime() - started) / 1e9
            + "\n");
    System.out.println("CONCRETE_FAILURE_OUTPUT_DIRECTORY=" + _outputDir);
  }

  private static boolean selectedOutputProtocol(String protocolName) {
    String normalized = protocolName.toLowerCase(java.util.Locale.ROOT);
    Set<SmtProtocolSelection.Family> selected = SmtProtocolSelection.fromRuntime();
    return (selected.contains(SmtProtocolSelection.Family.BGP)
            && (normalized.equals("bgp") || normalized.equals("ibgp")))
        || (selected.contains(SmtProtocolSelection.Family.OSPF) && normalized.startsWith("ospf"))
        || (selected.contains(SmtProtocolSelection.Family.ISIS) && normalized.startsWith("isis"));
  }

  @After
  public void clearOutputDirectory() {
    System.clearProperty(OUTPUT_DIRECTORY_PROPERTY);
  }

  private static String createNumberedOutputDirectory(String outputPrefix) throws IOException {
    String directoryPrefix = System.getenv("SMT_DIRECTORY_PREFIX");
    if (directoryPrefix == null) {
      throw new IllegalArgumentException("SMT_DIRECTORY_PREFIX must be set");
    }
    for (int i = 1; i <= 9999; i++) {
      Path candidate = Paths.get(directoryPrefix, String.format("%s%04d", outputPrefix, i));
      try {
        return Files.createDirectory(candidate).toString();
      } catch (java.nio.file.FileAlreadyExistsException e) {
        // Try the next stable output index.
      }
    }
    throw new IOException("no free symbolic output directory index remains");
  }

  private void writeToleranceSymbolicRoutes(DataPlane dataPlane) throws IOException {
    try (Context context = new Context()) {
      BatfishSymbolicRoutePipelineResult result = runSymbolicRoutePipeline(dataPlane, context);
      Files.write(
          Paths.get(_outputDir, "symbolic_route.txt"),
          result.toReadableText().getBytes(StandardCharsets.UTF_8));
      Files.write(
          Paths.get(_outputDir, "symbolic_route.json"),
          result.toControlPlaneJson().getBytes(StandardCharsets.UTF_8));
      Files.write(
          Paths.get(_outputDir, "symbolic_route_k_pruned.txt"),
          result.toKFailurePrunedReadableText(K).getBytes(StandardCharsets.UTF_8));
    }
  }

  private void writeSymbolicRoutes(DataPlane dataPlane) throws IOException {
    try (Context context = new Context()) {
      writeSymbolicRouteFiles(runSymbolicRoutePipeline(dataPlane, context));
    }
  }

  private void writeSnapshotSymbolicRoutes(DataPlane dataPlane, String configPath)
      throws IOException {
    if (Files.isRegularFile(Paths.get(configPath, "traffic.json"))) {
      writeTrafficSymbolicRoutes(dataPlane, configPath);
    } else {
      writeSymbolicRoutes(dataPlane);
    }
  }

  private void writeTrafficSymbolicRoutes(DataPlane dataPlane, String configPath)
      throws IOException {
    Path trafficInput = Paths.get(configPath, "traffic.json");
    if (!Files.isRegularFile(trafficInput)) {
      throw new IOException("Missing traffic input: " + trafficInput);
    }
    Files.copy(trafficInput, Paths.get(_outputDir, "0_traffic.json"), REPLACE_EXISTING);
    Set<Prefix> destinations = readTrafficDestinations(trafficInput);
    TrafficGraph trafficGraph = TrafficGraph.fromTrafficJson(trafficInput);
    try (Context context = new Context()) {
      BatfishSymbolicRoutePipelineResult controlPlaneResult =
          runSymbolicRoutePipeline(dataPlane, context);
      writeSymbolicRouteFiles(controlPlaneResult, destinations);
      writeSymbolicTrafficFiles(
          trafficGraph, runSymbolicTrafficPipeline(dataPlane, trafficGraph, controlPlaneResult));
    }
  }

  private SymbolicTrafficPipeline.Result runSymbolicTrafficPipeline(
      DataPlane dataPlane,
      TrafficGraph trafficGraph,
      BatfishSymbolicRoutePipelineResult controlPlaneResult) {
    SortedMap<String, org.batfish.datamodel.Configuration> configurations =
        _batfish.loadConfigurations(_batfish.getSnapshot());
    return SymbolicTrafficPipeline.run(trafficGraph, controlPlaneResult, configurations, dataPlane);
  }

  private void writeSymbolicTrafficFiles(
      TrafficGraph trafficGraph, SymbolicTrafficPipeline.Result result) throws IOException {
    Files.write(
        Paths.get(_outputDir, "0_traffic_graph.txt"),
        trafficGraph.toInputText().getBytes(StandardCharsets.UTF_8));
    Files.write(
        Paths.get(_outputDir, "0_symbolic_traffic_execution.txt"),
        result.toExecutionText().getBytes(StandardCharsets.UTF_8));
    Files.write(
        Paths.get(_outputDir, "0_symbolic_traffic_loads.json"),
        result.toYuJson().getBytes(StandardCharsets.UTF_8));
    Files.write(
        Paths.get(_outputDir, "0_traffic_loads.json"),
        result.toConcreteJson().getBytes(StandardCharsets.UTF_8));
    Files.write(
        Paths.get(_outputDir, TrafficSmtEncoder.SMT_FILE_NAME),
        result.toTrafficSmt().getBytes(StandardCharsets.UTF_8));
  }

  private Set<Prefix> readTrafficDestinations(Path trafficInput) throws IOException {
    JsonNode flows = BatfishObjectMapper.mapper().readTree(trafficInput.toFile()).get("flows");
    if (flows == null || !flows.isArray()) {
      throw new IOException("traffic.json must contain a flows array");
    }
    ImmutableSet.Builder<Prefix> destinations = ImmutableSet.builder();
    for (JsonNode flow : flows) {
      JsonNode destination = flow.get("destination");
      if (destination == null || !destination.isTextual()) {
        throw new IOException("every traffic flow must contain a textual destination");
      }
      try {
        destinations.add(Prefix.parse(destination.textValue()));
      } catch (IllegalArgumentException e) {
        throw new IOException("invalid traffic destination: " + destination.textValue(), e);
      }
    }
    Set<Prefix> result = destinations.build();
    if (result.isEmpty()) {
      throw new IOException("traffic.json flows must not be empty");
    }
    return result;
  }

  private static long recordGenerationPhase(String name, long started) {
    long ended = System.nanoTime();
    if (Boolean.parseBoolean(System.getenv("SMT_PROFILE_GENERATION"))) {
      System.out.println("GENERATION_PHASE=" + name + "," + (ended - started) / 1e9);
    }
    return ended;
  }

  private BatfishSymbolicRoutePipelineResult runSymbolicRoutePipeline(
      DataPlane dataPlane, Context context) {
    long phase = System.nanoTime();
    SortedMap<String, org.batfish.datamodel.Configuration> configurations =
        _batfish.loadConfigurations(_batfish.getSnapshot());
    IsisTopology isisTopology =
        IsisTopology.initIsisTopology(configurations, synthesizeL3Topology(configurations));
    BatfishSymbolicRoutePipelineInput input =
        BatfishParsedSnapshotPipelineInputBuilder.buildSelected(
            configurations,
            dataPlane.getRibs(),
            _batfish.getTopologyProvider().getBgpTopology(_batfish.getSnapshot()).getGraph(),
            isisTopology,
            new Z3RouteGuardFactory(context),
            SmtProtocolSelection.fromRuntime());
    phase = recordGenerationPhase("symbolic_input_build", phase);
    BatfishSymbolicRoutePipelineResult result = BatfishSymbolicRoutePipeline.run(input);
    recordGenerationPhase("symbolic_convergence", phase);
    return result;
  }

  private void writeSymbolicRouteFiles(BatfishSymbolicRoutePipelineResult result)
      throws IOException {
    writeSymbolicRouteFiles(result, null);
  }

  private void writeSymbolicRouteFiles(
      BatfishSymbolicRoutePipelineResult result, Set<Prefix> destinations) throws IOException {
    long phase = System.nanoTime();
    Files.write(
        Paths.get(_outputDir, "0_symbolic_routes_init.txt"),
        result.toRawReadableText().getBytes(StandardCharsets.UTF_8));
    Files.write(
        Paths.get(_outputDir, "0_symbolic_routes.txt"),
        (destinations == null
                ? result.toReadableText()
                : result.toReadableTextForDestinations(destinations))
            .getBytes(StandardCharsets.UTF_8));
    phase = recordGenerationPhase("symbolic_text_export", phase);
    byte[] controlPlaneJson = result.toControlPlaneJson().getBytes(StandardCharsets.UTF_8);
    Files.write(Paths.get(_outputDir, "0_symbolic_control_plane.json"), controlPlaneJson);
    Files.write(Paths.get(_outputDir, "symbolic_route.json"), controlPlaneJson);
    recordGenerationPhase("symbolic_json_export", phase);
    if (Boolean.parseBoolean(System.getenv("SMT_PROFILE_GENERATION"))) {
      System.out.println("GUARD_EQUIVALENCE=" + Z3RouteGuard.equivalenceProfile());
    }
    System.out.println(
        "CONFIG_TO_SYMBOLIC_ROUTE_SECONDS="
            + (System.nanoTime() - _configurationInputStarted) / 1e9);
    Files.write(
        Paths.get(_outputDir, "0_symbolic_sr_policies.json"),
        result.toSrPolicyExportJson().getBytes(StandardCharsets.UTF_8));
    Files.write(
        Paths.get(_outputDir, "0_symbolic_sr_policies.txt"),
        (destinations == null
                ? result.toSrPolicyReadableText()
                : result.toSrPolicyReadableTextForDestinations(destinations))
            .getBytes(StandardCharsets.UTF_8));
  }

  /**
   * Test network property: Reachability (or Isolation with negated) via SMT. You can set node
   * failures (or not) or edge failures (or not).
   */
  @Test
  public void testReachability() {
    final ReachabilityQuestion question = new ReachabilityQuestion();

    // tolerance-symbolic traffic
    // question.setIngressNodeRegex("s");
    // question.setFinalNodeRegex("d");
    // IpWildcard ipWildcard = IpWildcard.parse("5.5.5.5/32");
    // question.setDstIps(Set.of(ipWildcard));

    // tolerance-symbolic-route
    question.setIngressNodeRegex(System.getenv().getOrDefault("SMT_INGRESS", "r4"));
    question.setFinalNodeRegex(System.getenv().getOrDefault("SMT_FINAL", "r1"));
    IpWildcard ipWildcard =
        IpWildcard.parse(System.getenv().getOrDefault("SMT_DST", "10.0.0.0/24"));
    question.setDstIps(Set.of(ipWildcard));
    String failures = System.getenv("SMT_FAILURES");
    if (failures != null) {
      question.setFailures(Integer.parseInt(failures));
    }

    // user-study specification 1: ECMP reachability
    // question.setIngressNodeRegex("r3");
    // question.setFinalNodeRegex("isp2");
    // IpWildcard ipWildcard = IpWildcard.parse("203.0.113.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // user-study specification 2: Private prefix filtering
    // question.setIngressNodeRegex("r3");
    // question.setFinalNodeRegex("customer");
    // IpWildcard ipWildcard = IpWildcard.parse("192.168.128.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    // question.setNegate(true);
    //
    // question.setIngressNodeRegex("r3");
    // question.setFinalNodeRegex("customer");
    // IpWildcard ipWildcard = IpWildcard.parse("192.168.129.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    // question.setNegate(true);

    // user-study specification 3: Customer reachability
    // question.setIngressNodeRegex("customer");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("198.51.100.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // user-study specification 4: No transit
    // question.setIngressNodeRegex("isp2");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("192.0.2.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    // question.setNegate(true);
    //
    // question.setIngressNodeRegex("isp2");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("198.51.100.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    // question.setNegate(true);
    //
    // question.setIngressNodeRegex("isp1");
    // question.setFinalNodeRegex("isp2");
    // IpWildcard ipWildcard = IpWildcard.parse("203.0.113.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    // question.setNegate(true);

    // -------------------------------------------------------------

    // Specification 01: Qualification test 1
    // question.setIngressNodeRegex("customer");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("192.0.2.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // Specification 02: Qualification test 2
    // question.setIngressNodeRegex("customer");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("198.51.100.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    // question.setNegate(true);

    // -------------------------------------------------------------

    // Specification 01: Qualification test 1 (for introduction)
    // question.setIngressNodeRegex("customer");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("10.0.0.0/8");
    // question.setDstIps(Set.of(ipWildcard));

    // Specification 02: Qualification test 2 (for introduction)
    // question.setIngressNodeRegex("customer");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("192.168.0.0/16");
    // question.setDstIps(Set.of(ipWildcard));
    // question.setNegate(true);

    // -------------------------------------------------------------

    // Specification 01: Coursera test 1
    // question.setIngressNodeRegex("r1");
    // question.setFinalNodeRegex("customer");
    // IpWildcard ipWildcard = IpWildcard.parse("192.168.0.0/16");
    // question.setDstIps(Set.of(ipWildcard));
    // question.setNegate(true);

    // -------------------------------------------------------------

    // FatTree benchmarks - fattree4pol
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("edge-19");
    // IpWildcard ipWildcard = IpWildcard.parse("70.0.19.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // FatTree benchmarks - fattree8pol
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("edge-79");
    // IpWildcard ipWildcard = IpWildcard.parse("70.0.79.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // FatTree benchmarks - fattree12pol
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("edge-179");
    // IpWildcard ipWildcard = IpWildcard.parse("70.0.179.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // FatTree benchmarks - fattree16pol
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("edge-319");
    // IpWildcard ipWildcard = IpWildcard.parse("70.1.63.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // FatTree benchmarks - fattree20pol
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("edge-499");
    // IpWildcard ipWildcard = IpWildcard.parse("70.1.243.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // FatTree benchmarks - fattree24pol
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("edge-719");
    // IpWildcard ipWildcard = IpWildcard.parse("70.2.207.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // FatTree benchmarks - fattree28pol
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("edge-979");
    // IpWildcard ipWildcard = IpWildcard.parse("70.3.211.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // FatTree benchmarks - fattree32pol
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("edge-1279");
    // IpWildcard ipWildcard = IpWildcard.parse("70.4.255.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // -------------------------------------------------------------

    // Line benchmarks - line10
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("10.1.1.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // Line benchmarks - line100
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("10.5.4.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // Line benchmarks - line1000
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("10.5.49.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // Line benchmarks - line2000
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("10.10.49.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // Line benchmarks - line5000
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("10.20.62.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // Line benchmarks - line10000
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("isp1");
    // IpWildcard ipWildcard = IpWildcard.parse("10.20.124.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // -------------------------------------------------------------

    // Bics benchmarks
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peergeneva_8");
    // IpWildcard ipWildcard = IpWildcard.parse("128.0.8.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peerbrussels_4");
    // IpWildcard ipWildcard = IpWildcard.parse("128.0.4.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peerfrankfurt_7");
    // IpWildcard ipWildcard = IpWildcard.parse("200.1.27.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("luxembourg");
    // IpWildcard ipWildcard = IpWildcard.parse("200.1.51.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("madrid");
    // IpWildcard ipWildcard = IpWildcard.parse("200.1.56.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("strasbourg");
    // IpWildcard ipWildcard = IpWildcard.parse("200.1.64.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("zagreb");
    // IpWildcard ipWildcard = IpWildcard.parse("200.1.59.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("warsaw");
    // IpWildcard ipWildcard = IpWildcard.parse("200.1.67.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peergeneva_9");
    // IpWildcard ipWildcard = IpWildcard.parse("200.1.54.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peermarseille_13");
    // IpWildcard ipWildcard = IpWildcard.parse("200.1.19.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // -------------------------------------------------------------

    // Columbus benchmarks
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("grenada");
    // IpWildcard ipWildcard = IpWildcard.parse("200.2.55.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peerdominicanttrepublic_1");
    // IpWildcard ipWildcard = IpWildcard.parse("128.0.1.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peernodeid1_2");
    // IpWildcard ipWildcard = IpWildcard.parse("128.0.4.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peernodeid31_6");
    // IpWildcard ipWildcard = IpWildcard.parse("128.0.6.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("nodeid44");
    // IpWildcard ipWildcard = IpWildcard.parse("200.2.100.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("nodeid50");
    // IpWildcard ipWildcard = IpWildcard.parse("200.2.101.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peerstttcroix_13");
    // IpWildcard ipWildcard = IpWildcard.parse("200.2.102.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peernodeid46_10");
    // IpWildcard ipWildcard = IpWildcard.parse("200.2.22.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peerpanama_12");
    // IpWildcard ipWildcard = IpWildcard.parse("200.2.35.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("curacao");
    // IpWildcard ipWildcard = IpWildcard.parse("200.2.37.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // -------------------------------------------------------------

    // USCarrier benchmarks
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peerjacksonvilleid5_8");
    // IpWildcard ipWildcard = IpWildcard.parse("128.0.8.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("peeralbany_0");
    // IpWildcard ipWildcard = IpWildcard.parse("128.0.0.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("cartersville");
    // IpWildcard ipWildcard = IpWildcard.parse("200.4.127.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("kinston");
    // IpWildcard ipWildcard = IpWildcard.parse("200.4.145.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("warwick");
    // IpWildcard ipWildcard = IpWildcard.parse("200.4.169.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("waynesboro");
    // IpWildcard ipWildcard = IpWildcard.parse("200.4.172.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("greenwood");
    // IpWildcard ipWildcard = IpWildcard.parse("200.4.178.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("hagerstown");
    // IpWildcard ipWildcard = IpWildcard.parse("200.4.197.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("aiken");
    // IpWildcard ipWildcard = IpWildcard.parse("200.4.202.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex(".*");
    // question.setFinalNodeRegex("ringgold");
    // IpWildcard ipWildcard = IpWildcard.parse("200.4.214.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    // -------------------------------------------------------------

    // Internet2 benchmarks
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("100.64.10.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("205.213.200.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("128.10.50.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("128.2.100.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("128.206.50.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("128.101.10.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("63.193.200.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("198.48.92.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("74.115.8.0/24");
    // question.setDstIps(Set.of(ipWildcard));
    //
    // question.setIngressNodeRegex("chic-re1");
    // question.setFinalNodeRegex("wiscr");
    // IpWildcard ipWildcard = IpWildcard.parse("63.164.11.0/24");
    // question.setDstIps(Set.of(ipWildcard));

    long encodingStarted = System.nanoTime();
    final AnswerElement answer = Answerer.create(question, _batfish).answer(_batfish.getSnapshot());
    recordGenerationPhase("minesweeper_encode_and_verify", encodingStarted);
    assertThat(answer, instanceOf(SmtReachabilityAnswerElement.class));

    final SmtReachabilityAnswerElement smtAnswer = (SmtReachabilityAnswerElement) answer;
    assertThat(smtAnswer.getResult().isVerified(), is(true));
  }

  /**
   * Test network property: Bounded Length via SMT. You can set node failures (or not) or edge
   * failures (or not).
   */
  /*
  @Test
  public void testBoundedLength() {
      final BoundedLengthQuestion question = new BoundedLengthQuestion();
      question.setBound(3);
      question.setIngressNodeRegex("customer1");
      question.setFinalNodeRegex("isp1");
      question.setFinalIfaceRegex("GigabitEthernet3/0");

      final AnswerElement answer = Answerer.create(question, _batfish).answer(_batfish.getSnapshot());
      assertThat(answer, instanceOf(SmtOneAnswerElement.class));

      final SmtOneAnswerElement smtAnswer = (SmtOneAnswerElement) answer;
      assertThat(smtAnswer.getResult().isVerified(), is(true));
  }
   */

  /**
   * Test network property: Bounded Length via SMT. You can set node failures (or not) or edge
   * failures (or not).
   */
  /*
  @Test
  public void testBlackhole() {
      final BlackholeQuestion question = new BlackholeQuestion();
      // question.setIngressNodeRegex("customer1");
      // question.setFinalNodeRegex("isp1");
      // question.setFinalIfaceRegex("GigabitEthernet3/0");

      final AnswerElement answer = Answerer.create(question, _batfish).answer(_batfish.getSnapshot());
      assertThat(answer, instanceOf(SmtOneAnswerElement.class));

      final SmtOneAnswerElement smtAnswer = (SmtOneAnswerElement) answer;
      assertThat(smtAnswer.getResult().isVerified(), is(true));
  }
   */

  /**
   * Load configurations, hosts and iptables files from specified directory.
   *
   * @param configPathStr base path to the directory containing "configs", "hosts", and "iptables"
   *     subdirectories.
   * @return TestrigText object containing all loaded file bytes.
   */
  public static TestrigText loadConfigurations(String configPathStr) {
    try {
      // Ensure directory path ends with separator
      if (!configPathStr.endsWith("/") && !configPathStr.endsWith("\\")) {
        configPathStr += System.getProperty("file.separator");
      }
      if (!Files.isDirectory(Paths.get(configPathStr, "configs"))) {
        throw new IOException("missing configs directory: " + configPathStr + "configs");
      }

      SortedMap<String, byte[]> configurationsBytes =
          ConfigLoader.loadAllFiles(configPathStr + "configs", ".cfg");
      SortedMap<String, byte[]> hostsBytes =
          ConfigLoader.loadAllFiles(configPathStr + "hosts", ".json");
      SortedMap<String, byte[]> iptablesBytes =
          ConfigLoader.loadAllFiles(configPathStr + "iptables", ".iptables");

      return TestrigText.builder()
          .setConfigurationBytes(configurationsBytes)
          .setHostsBytes(hostsBytes)
          .setIptablesBytes(iptablesBytes)
          .build();

    } catch (IOException e) {
      throw new IllegalArgumentException(
          "Failed to load configurations from " + configPathStr + ": " + e.getMessage(), e);
    }
  }
}
